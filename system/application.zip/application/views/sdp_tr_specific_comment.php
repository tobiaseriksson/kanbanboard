<table><tr><td>
<div class="post">
<div class="content">
<table><tr><td>
<h2 class="title">Add or Modify TR specific comment</h2>
<p class="meta"><small>Here it is possible to specify a comment that is specific for this TR and for this Release</small></p>
<form name="adddocument" action="<?php echo site_url( '/sdp/trspecificcomment/'.$id.'/'.$tr_id ); ?>" method="post">
<input type="hidden" name="tr_id" value="<?php echo $tr_id; ?>" />
<input type="hidden" name="tr_number" value="<?php echo $tr_number; ?>" />
<table>
<tr><td colspan=3>
	<table>
	<tr><td>Release name</td><td><?php echo $header; ?></td></tr>
	<tr><td>TR#</td><td><?php echo $tr_number; ?></td></tr>
	<tr><td>TR-Title</td><td><?php echo $tr_title; ?></td></tr>
	</table>
</td></tr>
<tr><td>Comment</td></tr>
<tr><td><input name="comment" value="<?php echo $comment; ?>" type="text" size="45"> </td></tr>
<tr><td align="left" valign="top" class="errortext"><?php echo $errortext;?></td></tr>
<tr><td colspan=3 align="right"><input name="submit" type="submit" value="submit" /></td></tr>
</table>

</form>
<br>
</p>
</td><td width="30px"></td></tr></table>
</div>
</div>
</td></tr></table>
