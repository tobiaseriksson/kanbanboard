<table><tr><td>
<div class="post">
<div class="content">
<table><tr><td>
<h2 class="title">Administration</h2>
<p class="meta">&nbsp;</p>
<p></p>
<p><a href="/sdp/register">Register</a>, a new user.</p>
<p><a href="/sdp/lostpassword">Lost Your Password?</a></p>
<p><a href="/sdp/updatetrstatus">Update</a>, the status of all TRs, by retieving information from MHWeb.</p>
<p><a href="/sdp/loadicpdata_not">Load</a>, the old ICP-content-plan.</p>
<p>
<br>
<br>
</p>
</td><td width="30px"></td></tr></table>
</div>
</div>
</td></tr></table>

