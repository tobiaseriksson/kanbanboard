<html>
<head>
<title>Select Project</title>


</head>
<body>
<h2>Kanban Projects</h2>
<div>
<?php
foreach ($projects as $project) {		
	echo '<A HREF="kanban/project/'.$project['id'].'">'.$project['name'].'</A>';
	echo '<br>';
}
?>	


	<h2>Add New Project</h2>
	<form id="newproject" name="newproject" action="kanban/addproject" method="post">	
		<div>
			<table>
				<tr><td>Project Name :</td><td><input name="name"  style="z-index: 100; position: relative" title="type &quot;a&quot;" /></td></tr>
				<tr>
					<td></td>
					<td>
						<input type="submit" name="g" value="Submit" id="g" /> 
					</td>
				</tr>
			</table>
		</div>
	</form>

</div>
</body>
</html>

