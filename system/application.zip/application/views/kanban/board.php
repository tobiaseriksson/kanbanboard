<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<title>The '<?php echo $projectname; ?>' Kanban Board</title>	
	<link type="text/css" href="/assets/css/smoothness/jquery-ui-1.8.1.custom.css" rel="stylesheet" />	
	<script type="text/javascript" src="/assets/js/jquery-1.4.2.min.js"></script>
	<script type="text/javascript" src="/assets/js/jquery-ui-1.8.1.custom.min.js"></script>
	<script type="text/javascript">
		$(function() {
			$("#tabs").tabs();
		});
	</script>


	<style type="text/css">
		#sortablegroup { list-style-type: none; margin: 0; padding: 0; width: 100%; }
		#sortablegroup li { margin: 0 3px 3px 3px; padding: 0.4em; padding-left: 1.5em; padding-right: 1.5em; font-size: 1.1em; height: 18px; }
		#sortablegroup li span { position: absolute; margin-left: -1.3em; }
	</style>


	<style type="text/css">
			/*demo page css*/
			body{ font: 62.5% "Trebuchet MS", sans-serif; margin: 50px;}
			.demoHeaders { margin-top: 2em; }
			#dialog_link {padding: .4em 1em .4em 20px;text-decoration: none;position: relative;}
			#dialog_link span.ui-icon {margin: 0 5px 0 0;position: absolute;left: .2em;top: 50%;margin-top: -8px;}
			ul#icons {margin: 0; padding: 0;}
			ul#icons li {margin: 2px; position: relative; padding: 4px 0; cursor: pointer; float: left;  list-style: none;}
			ul#icons span.ui-icon {float: left; margin: 0 4px;}
			div.kanbanactions { background-color: white; color: black; border-style: none; }
			div.kanbanboard { display: block; background-color: red; color: black; border-style: none; }
		</style>
	

		<style type="text/css">
<?php

$first=1;
foreach ($groups as $row) {	
	if( $first < 1 ) echo ",";
	$first=0;		
	echo "#sortable".$row['id']." ";
}
echo " { list-style-type: none; margin: 0; padding: 0; float: left; margin-right: 10px; }\n";
$first=1;
foreach ($groups as $row) {			
	if( $first < 1 ) echo ",";
	$first=0;		
	echo "#sortable".$row['id']." li ";
}
echo " { margin: 0 5px 5px 5px; padding: 5px; font-size: 1.1em; width: 120px; }\n";

?>

		</style>
	
		<script type="text/javascript">
			$(function() {
				$("<?php 
					$first=1; 
					foreach ($groups as $row) {
						if( $first < 1 ) echo ",";
						$first=0;		
						echo "#sortable".$row['id']." ";
					}
					?>").sortable({
				connectWith: '.connectedSortable',
				items: 'li:not(.rubrik)',
				receive: function(event, ui) { 
						$("#mertext").append( "Event:"+ui.sender.attr("id")+", item="+ui.item.attr("id")+", placeholder="+ui.placeholder.attr("id")+", event.target = "+event.target.id+"<br>" ); 
						var from = ui.sender.attr("id").replace( "sortable", "" );
						var to = event.target.id.replace( "sortable", "" );
						var task = ui.item.attr("id").replace( "task", "" );
						var dataString = 'from='+ from + '&to=' + to + "&task=" + task;
						$("#quote").html("res="+dataString);
						// alert (dataString);return false;
						$.ajax({  
						  type: "POST",  
						  url: "/kanban/move",  
						  data: dataString,  
						  success: function(data) {  
						    $("#quote").html("This is the result"+data);  				     
						  }  
						});  
						return false;
				}
			}).disableSelection();
		});
	</script>
	
	<script type="text/javascript">
		$(function() {
			$('#newtask').submit(function() {
				// alert("form="+$(this).attr('id')+"res="+$(this).serialize());				
				var dataString = $("#newtask").serialize();
				$("#quote").html("res="+dataString);
				// alert (dataString);return false;  
				$.ajax({  
				  type: "POST",  
				  url: "/kanban/add",  
				  data: dataString,  
				  success: function(data) {  
				    $("#quote").html("This is the result"+data);  				     
				  }  
				});  
			  	return false;
			});	
		});
			
	</script>

	<script type="text/javascript">
		$(function() {
			$('#newgroup').submit(function() {
				// alert("form="+$(this).attr('id')+"res="+$(this).serialize());				
				var dataString = $("#newgroup").serialize();
				$("#quote").html("res="+dataString);
				//alert (dataString);return false;  
				$.ajax({  
				  type: "POST",  
				  url: "/kanban/addgroup",  
				  data: dataString,  
				  success: function(data) {  
				    $("#groupresult").html("This is the result"+data);  				     
				  }, 
				  error: function(x,e) {  
				    $("#groupresult").html("failed with; "+x.status+", e="+e+", response="+x.responseText);
				  }  
				});  
			  	return false;
			});	
		});
			
	</script>

	<script type="text/javascript">
		$(function() {
			$("#sortablegroup").sortable({
				stop: function(event, ui) { 
					
					var grouporder='';
					$('#sortablegroup li').each(function() {
						grouporder=grouporder+$(this).attr('id').replace('sgroup','')+',';
					});
					$("#groupresult").html("order; "+grouporder);
					var dataString = 'grouporder='+grouporder+'&'+'projectid='+<?php echo $projectid; ?>;
					$.ajax({  
					  type: "POST",  
					  url: "/kanban/changegrouporder",  
					  data: dataString,  
					  success: function(data) {  
					    $("#groupresult").html("This is the result"+data);  				     
					  }, 
					  error: function(x,e) {  
					    $("#groupresult").html("failed with; "+x.status+", e="+e+", response="+x.responseText);
					  }  
					});  
					
				}
			});

			$("#sortablegroup").disableSelection();
		});
	</script>

	<script type="text/javascript">
		$(function() {
			$( "#dialog-edit-task" ).dialog({
			modal: false,
			autoOpen: false,
			buttons: {
				Ok: function() {
					$( this ).dialog( "close" );
				}
			}
		   });
		});
	</script>

	<script type="text/javascript">
	
	function fillInFormTaskDetails( taskid ) {
		var projectid = <?php echo $projectid; ?>;
		var dataString = "";
		$.ajax({  
		  dataType: "json",  
		  url: "/kanban/taskdetails/"+projectid+"/"+taskid,  
		  data: dataString,  
		  success: function(data) {  
			$("#groupresult").html("success="+data.heading);
			$("#heading").val( data.heading);
			$("#taskdescription").val( data.taskdescription);
			$("#priority").val( data.priority);
			$("#estimation").val( data.estimation);
			$("#priority").val( data.priority);
			$("#projectid").val( data.projectid);
			$("#taskid").val( data.taskid);
		   $("#updatetask").fill(data);  				     
		  }, 
		  error: function(x,e) {  
		    $("#groupresult").html("failed with; "+x.status+", e="+e+", response="+x.responseText);
		  }  
		});  
	}
	</script>

</head>
<body bgcolor=grey>

<div id="dialog-edit-task" title="Edit Task">	
	<p>
	<form id="updatetask" name="updatetask" action="">
		<input type="hidden" name="projectid" id="projectid" value="<?php echo $projectid; ?>" />
		<input type="hidden" name="taskid" id="taskid" value="0" />
		<div>
			<table>
				<tr><td>Task :</td><td><input name="heading" id="heading" style="z-index: 100; position: relative" title="type &quot;a&quot;" /></td></tr>
				<tr><td>Text :</td><td><textarea name="taskdescription"  id="taskdescription" rows="10" cols="20" style="z-index: 100; position: relative" title="type &quot;a&quot;" ></textarea></td></tr>
				<tr><td> Priority :</td><td>
					<input name="priority" id="priority"  style="z-index: 100; position: relative" title="type &quot;a&quot;" value="100" />
				</td></tr>
				<tr><td> Estimate :</td><td>
					<input name="estimation" id="estimation"  style="z-index: 100; position: relative" title="type &quot;a&quot;" value="0" />
				</td></tr><tr>
					<td></td>
					<td>
						<input type="submit" name="g" value="Submit" id="g" /> 
					</td>
				</tr>
			</table>
		</div>
	</form>		
	</p>
</div>


<h2>The '<?php echo $projectname; ?>' Kanban Board</h2>
<a href="/kanban/settings/<?php echo $projectid; ?>">Project Settings</a>
<div >

<div id="tabs">
	<ul>
		<li><a href="#tabs-1">Add Task</a></li>
		<li><a href="#tabs-2">Manage Groups</a></li>
		<li><a href="#tabs-3">Preferences</a></li>
	</ul>
	<div id="tabs-1">
		<p>
<div class="kanbanactions">
	<h2>Add New Task</h2>
	<form id="newtask" name="newtask" action="">
	<input type="hidden" name="projectid" value="<?php echo $projectid; ?>" />
		<div>
			<table>
				<tr>
					<td> Group :</td>
					<td>
						<select name="group"><option value="1">unassigned</option><option value="2">unassigned</option><option value="3">team 10</option><option value="4">team umi</option><option value="5">finished</option></select>
					</td>
				</tr>
				<tr><td>New Task/TR :</td><td><input name="heading"  style="z-index: 100; position: relative" title="type &quot;a&quot;" /></td></tr>
				<tr><td>Text :</td><td><textarea name="taskdescription" rows="10" cols="30" style="z-index: 100; position: relative" title="type &quot;a&quot;" ></textarea></td></tr>
				<tr><td> Priority :</td><td>
					<input name="priority"  style="z-index: 100; position: relative" title="type &quot;a&quot;" value="100" />
				</td></tr>
				<tr><td> Estimate :</td><td>
					<input name="estimation"  style="z-index: 100; position: relative" title="type &quot;a&quot;" value="0" />
				</td></tr><tr>
					<td></td>
					<td>
						<input type="submit" name="g" value="Submit" id="g" /> 
					</td>
				</tr>
			</table>
		</div>
	</form>

</div>


		</p>
	</div>
	<div id="tabs-2">
		<p><div class="kanbanactions">
	<h2>Manage Groups</h2>
	<form id="newgroup" name="newgroup" action="">
	<input type="hidden" name="projectid" value="<?php echo $projectid; ?>" />
		<div>
			<table border=1 >
			<tr><td valign=top>
				<table >					
					<tr><td> Name :</td><td>
						<input name="name"  style="z-index: 100; position: relative" title="type &quot;a&quot;" value="any name" />
					</td></tr><tr>
						<td></td>
						<td align="right">
							<input type="submit" name="g" value="Submit" id="g" /> 
						</td>
					</tr>
				</table>
			</td>
			<td valign=top>
				<table>					
					<tr><td> Order :</td><td>
					<tr><td>
						<ul id="sortablegroup" >
						<?php						
						foreach ($groups as $group) {		
							
							echo ' <li id="sgroup'.$group['id'].'"  class="ui-state-highlight">'.$group['name'].'</li>'."\n";
														
						}						
						?>
						</ul>
					</td><td>
					</tr>
				</table>
			</td>
			<td valign=top>
				<table width="200px">					
					<tr><td> Result :</td></tr>
					<tr><td valign=top>
						<div id="groupresult">
						</div>
					</td></tr>
				</table>
			</td>
			</tr>
			</table>
		</div>
	</form>

</div></p>
	</div>
	<div id="tabs-3">
		<p>Mauris eleifend est et turpis. Duis id erat. Suspendisse potenti. Aliquam vulputate, pede vel vehicula accumsan, mi neque rutrum erat, eu congue orci lorem eget lorem. Vestibulum non ante. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Fusce sodales. Quisque eu urna vel enim commodo pellentesque. Praesent eu risus hendrerit ligula tempus pretium. Curabitur lorem enim, pretium nec, feugiat nec, luctus a, lacus.</p>
		<p>Duis cursus. Maecenas ligula eros, blandit nec, pharetra at, semper at, magna. Nullam ac lacus. Nulla facilisi. Praesent viverra justo vitae neque. Praesent blandit adipiscing velit. Suspendisse potenti. Donec mattis, pede vel pharetra blandit, magna ligula faucibus eros, id euismod lacus dolor eget odio. Nam scelerisque. Donec non libero sed nulla mattis commodo. Ut sagittis. Donec nisi lectus, feugiat porttitor, tempor ac, tempor vitae, pede. Aenean vehicula velit eu tellus interdum rutrum. Maecenas commodo. Pellentesque nec elit. Fusce in lacus. Vivamus a libero vitae lectus hendrerit hendrerit.</p>
	</div>
</div>

</div><!-- End demo -->

<div class="demo-description">

<p>Click tabs to swap between content that is broken into logical sections.</p>

</div><!-- End demo-description -->

<div class="kanbanboard">
<?php
$i=1;
$groupid=-1;
foreach ($groups as $group) {		
	echo '<ul id="sortable'.$group['id'].'" class="connectedSortable">';
	echo '<li class="ui-state-default rubrik">'.$group['name'].'</li>';
	$groupid = $group['id'];
	foreach ($tasks as $row)
	{					 
		if( $groupid == $row['group_id'] ) {
			echo '<li id="task'.$row['taskid'].'" class="ui-state-highlight"><table width="100%" border=0><tr><td colspan=2><b>'.$row['heading'].'</b></td></tr><tr><td>bla bla bla</td><td align=right><span class="ui-icon ui-icon-wrench" onclick="fillInFormTaskDetails('.$row['taskid'].'); $(\'#dialog-edit-task\').dialog(\'open\'); return false; "></span></td></tr></table></li>';
		}

	}
	echo "</ul>\n";
}
?>

</div><!-- End demo -->

mertext
	<div  id="mertext">
sdfsdfsdf
	</div>

quote
	<div id="quote"></div>

<div class="demo-description">

<p>
	Sort items from one list into another and vice versa, by passing a selector into
	the <code>connectWith</code> option. The simplest way to do this is to
	group all related lists with a CSS class, and then pass that class into the
	sortable function (i.e., <code>connectWith: '.myclass'</code>).
</p>

</div><!-- End demo-description -->



</body>
</html>

