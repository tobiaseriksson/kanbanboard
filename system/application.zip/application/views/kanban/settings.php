<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<title>The '<?php echo $projectname; ?>' Kanban Board</title>	
	<link type="text/css" href="/assets/css/smoothness/jquery-ui-1.8.1.custom.css" rel="stylesheet" />	
	<script type="text/javascript" src="/assets/js/jquery-1.4.2.min.js"></script>
	<script type="text/javascript" src="/assets/js/jquery-ui-1.8.1.custom.min.js"></script>

	<style type="text/css">
		#sortablegroup { list-style-type: none; margin: 0; padding: 0; width: 100%; }
		#sortablegroup li { margin: 0 3px 3px 3px; padding: 0.4em; padding-left: 1.5em; font-size: 1.4em; height: 18px; }
		#sortablegroup li span { position: absolute; margin-left: -1.3em; }
	</style>

	<style type="text/css">
<?php

$first=1;
foreach ($groups as $row) {	
	if( $first < 1 ) echo ",";
	$first=0;		
	echo "#sortable".$row['id']." ";
}
echo " { list-style-type: none; margin: 0; padding: 0; float: left; margin-right: 10px; }\n";
$first=1;
foreach ($groups as $row) {			
	if( $first < 1 ) echo ",";
	$first=0;		
	echo "#sortable".$row['id']." li ";
}
echo " { margin: 0 5px 5px 5px; padding: 5px; font-size: 1.2em; width: 120px; }\n";

?>

		</style>

	<script type="text/javascript">
		$(function() {
			$('#newtask').submit(function() {
				// alert("form="+$(this).attr('id')+"res="+$(this).serialize());				
				var dataString = $("#newtask").serialize();
				$("#quote").html("res="+dataString);
				// alert (dataString);return false;  
				$.ajax({  
				  type: "POST",  
				  url: "/kanban/add",  
				  data: dataString,  
				  success: function(data) {  
				    $("#quote").html("This is the result"+data);  				     
				  }  
				});  
			  	return false;
			});	
		});
			
	</script>

	<script type="text/javascript">
		$(function() {
			$('#newgroup').submit(function() {
				// alert("form="+$(this).attr('id')+"res="+$(this).serialize());				
				var dataString = $("#newgroup").serialize();
				$("#quote").html("res="+dataString);
				//alert (dataString);return false;  
				$.ajax({  
				  type: "POST",  
				  url: "/kanban/addgroup",  
				  data: dataString,  
				  success: function(data) {  
				    $("#quote").html("This is the result"+data);  				     
				  }  
				});  
			  	return false;
			});	
		});
			
	</script>


	<script type="text/javascript">
		$(function() {
			$("#sortablegroup").sortable();
			$("#sortablegroup").disableSelection();
		});
	</script>


</head>
<body>
These are the settings


<div class="kanbanactions">
	<h2>Add New Task</h2>
	<form id="newtask" name="newtask" action="">
	<input type="hidden" name="projectid" value="<?php echo $projectid; ?>" />
		<div>
			<table>
				<tr>
					<td> Group :</td>
					<td>
						<select name="group"><option value="1">unassigned</option><option value="2">unassigned</option><option value="3">team 10</option><option value="4">team umi</option><option value="5">finished</option></select>
					</td>
				</tr>
				<tr><td>New Task/TR :</td><td><input name="heading"  style="z-index: 100; position: relative" title="type &quot;a&quot;" /></td></tr>
				<tr><td>Text :</td><td><textarea name="taskdescription" rows="10" cols="30" style="z-index: 100; position: relative" title="type &quot;a&quot;" ></textarea></td></tr>
				<tr><td> Priority :</td><td>
					<input name="priority"  style="z-index: 100; position: relative" title="type &quot;a&quot;" value="100" />
				</td></tr>
				<tr><td> Estimate :</td><td>
					<input name="estimation"  style="z-index: 100; position: relative" title="type &quot;a&quot;" value="0" />
				</td></tr><tr>
					<td></td>
					<td>
						<input type="submit" name="g" value="Submit" id="g" /> 
					</td>
				</tr>
			</table>
		</div>
	</form>

</div>

<div class="kanbanactions">
	<h2>Manage Groups</h2>
	<form id="newgroup" name="newgroup" action="">
	<input type="hidden" name="projectid" value="<?php echo $projectid; ?>" />
		<div>
			<table border=1>
			<tr><td>
				<table>					
					<tr><td> Name :</td><td>
						<input name="name"  style="z-index: 100; position: relative" title="type &quot;a&quot;" value="any name" />
					</td></tr><tr>
						<td></td>
						<td align="right">
							<input type="submit" name="g" value="Submit" id="g" /> 
						</td>
					</tr>
				</table>
			</td><td>
				<table>					
					<tr><td> Order :</td><td>
					<tr><td>
						<ul id="sortablegroup" >
						<?php						
						foreach ($groups as $group) {		
							
							echo '<li id="sgroup'.$group['id'].'" class="ui-state-highlight">'.$group['name'].'</li>';
														
						}						
						?>
						</ul>
					</td><td>
					</tr>
				</table>
			</td>
			</tr>
			</table>
		</div>
	</form>

</div>



</body>
</html>

