<table><tr><td>
<div class="post">
<div class="content">
<table><tr><td>
<h2 class="title">Add / Modify File or Document for release</h2>
<p class="meta"><small>xxx</small></p>
<form name="adddocument" action="<?php echo site_url( '/sdp/adddocument/'.$id); ?>" method="post">
<input type="hidden" name="doc_id" value="<?php echo $doc_id; ?>" />
<table>
<tr><td colspan=3>
	<table>
	<tr><td>Release name</td><td><?php echo $header; ?></td></tr>
	</table>
</td></tr>
<tr><td>File/Document Number</td></tr>
<tr><td><input name="doc_number" value="<?php echo $doc_number;?>" type="text" size="45"> Rev <input name="doc_revision" value="<?php echo $doc_revision;?>" type="text" size="5"></td></tr>
<tr><td>Comment</td></tr>
<tr><td><input name="comment" value="<?php echo $comment;?>" type="text" size="45"> </td></tr>
<tr><td align="left" valign="top" class="errortext"><?php echo $errortext;?></td></tr>
<tr>
<?php if( $doc_id > 0 ) { ?>
<td align="left"><input name="submit" type="submit" value="Remove" /></td>
<?php } ?>
<td align="right"><input name="submit" type="submit" value="submit" /></td>
</tr>
</table>

</form>
<br>
</p>
</td><td width="30px"></td></tr></table>
</div>
</div>
</td></tr></table>


