<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>SDP ICP-Content Plan</title>

<link rel="alternate" href="<?php echo site_url( '/feed/anychange' ); ?>" type="application/rss+xml" title="All SDP ICP Content Changes" />
<link rel="alternate" href="<?php echo site_url( '/feed/deleted' ); ?>" type="application/rss+xml" title="Notification of any deleted TRs" />

<link href="/assets/css/default.css" rel="stylesheet" type="text/css">

<?php
if( isset( $formname ) ) {
	echo js_calendar_script($formname);
}
?>
</head>

<body>
<div class="header">
	<div class="beginning">
	<p class="title">SDP Design & Maintenance</p>
	<p class="menuitems">
	<a href="<?php echo site_url( '/sdp' )?>">Home</a> |
	<a href="<?php echo site_url( '/sdp/addrelease' )?>">Add Release</a> |
	<a href="<?php echo site_url( '/sdp/viewreleases' )?>">View All Releases</a> |
	<a href="<?php echo site_url( '/sdp/maptrstoreleases' )?>">Map TRs to Releases</a> |
	<a href="<?php echo site_url( '/sdp/mappcstoreleases' )?>">Map PCs to Releases</a> |
	<a href="<?php echo site_url( '/sdpfollowup' )?>">TR Followup</a> |
	<a href="<?php echo site_url( '/sdp/admin' )?>">Admin</a> |
	<a href="<?php echo site_url( '/sdp/rss' )?>">RSS Feeds</a> |
	<?php if( $this->session->userdata('username')== FALSE ) { ?>
	<a href="<?php echo site_url( '/sdp/login' )?>">Login</a>
	<?php } else {
	?>
	<a href="<?php echo site_url( '/sdp/logout' )?>">Logout</a>
	<?php
		echo "(".$this->session->userdata('username').")"; 
		}
	?>	
	</p>	
	</div>
</div>
