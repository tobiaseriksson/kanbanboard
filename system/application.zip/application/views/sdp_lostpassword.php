<table><tr><td>
<div class="post">
<div class="content">
<table><tr><td>
<h2 class="title">Lost Your Password ?</h2>
<p>Please select your username and we'll send you a password renewal-email.</p>
<table cellspacing="0px" class="tr-list">
<tr><th>#</th><th>email</th><th>username</th><th>team</th></tr>
<?php
$i=1;
$odd=1;
foreach ($users as $row)
		{
			if( $odd > 0 ) {
				$tr_class=" class=\"odd\" ";
			} else {
				$tr_class=" class=\"even\" ";
			}
			$odd=$odd*-1;
			echo "<tr ".$tr_class." >";
			echo "<td>".$i."</td>";
                        echo "<td>".$row['email']."</td>";
                        echo "<td>".$row['username']."</td>";
                        echo "<td>".$row['team']."</td>";
                        echo "</tr>\n";
			$i++;
		}
 ?>
</table>
<br>
<br>
</p>
</td><td width="30px"></td></tr></table>
</div>
</div>
</td></tr></table>

