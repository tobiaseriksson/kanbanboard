<table><tr><td>
<div class="post">
<div class="content">
<table><tr><td>
<h2 class="title">Login</h2>
<p>Not a user yet, <a href="<?php echo site_url( '/sdp/register');?>">then click here to Register</a></p>
<div class="errortext"><?php echo $errormessage."<br>"; ?></div>
<form name="login" action="<?php echo site_url( '/sdp/login');?>" method="post">
<input type="hidden" name="id" value="0" />
<input type="hidden" name="redirect_to_url" value="<?php echo $redirect_to_url; ?>" />
<table>
<tr><td>username</td><td><input type="text" name="username" size="15"></td></tr>
<tr><td>password</td><td><input type="password" name="password" size="15"></td></tr>
<tr><td></td><td align="right"><input type="submit" name="login" value="login"></td><td></td></tr>
</table>
</form>
<br>
</p>
</td><td width="30px"></td></tr></table>
</div>
</div>
</td></tr></table>


