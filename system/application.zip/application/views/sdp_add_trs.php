<table><tr><td>
<div class="post">
<div class="content">
<table><tr><td>
<h2 class="title">Add Release / Package to the SDP ICP Content plan</h2>
<p class="meta"><small>xxx</small></p>
<form name="addtrs" action="<?php echo site_url( '/sdp/addtrs/'.$id); ?>" method="post">
<input type="hidden" name="id" value="<?php echo $id; ?>" />
<input type="hidden" name="header" value="<?php echo $header; ?>" />
<table>
<tr><td colspan=3>
	<table>
	<tr><td>Release name</td><td><?php echo $header; ?></td></tr>
	</table>
</td></tr>
<tr><td><br></td></tr>
<tr><td>List of TRs (one TR per row)</td></tr>
<tr><td><textarea name="trlist" rows="20" cols="20"><?php echo $trlist;?></textarea></td><td align="left" valign="top" class="errortext"><?php echo $errortext;?></td></tr>
<tr><td><br></td></tr>
<tr><td>Optional <font color="#ff0000">Tag</font><br>(short tag to highlight these TRs)</td><td valign="top"><input name="tag" value="<?php echo $tag;?>" type="text" size="10"></td></tr>
<tr><td colspan=3 align="right"><input name="submit" type="submit" value="submit" /></td></tr>
</table>

</form>
<br>
</p>
</td><td width="30px"></td></tr></table>
</div>
</div>
</td></tr></table>

