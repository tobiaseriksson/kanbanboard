<table><tr><td>
<div class="post">
<div class="content">
<table><tr><td>
<h2 class="title">SDP ICP Content Page </h2>
<p class="meta"><small></small></p>
<p>Here are all the releases</p>
<p>
<i><A HREF="<?php echo site_url( '/sdp/viewreleaseswithfullinformation' ); ?>">Click here</A> for a list of all releases with dates for Content Freeze, Code Freeze, LSV Delivery and Delivery</i>
<table cellspacing="0px" class="tr-list">
<tr><th>#</th><th>Name</th><th>Delivery Date</th><th>Status</th><th>Modified</th></tr>
<?php
$i=1;
$odd=1;
foreach ($releases as $row)
		{
			if( $odd > 0 ) {
				$tr_class=" class=\"odd\" ";
			} else {
				$tr_class=" class=\"even\" ";
			}
			$odd=$odd*-1;
			echo "<tr ".$tr_class." ><td>".$i."</td><td nowrap><a href=\"".site_url( '/sdp/viewrelease/'.$row['id'] )."\">".$row['header']."</a></td><td nowrap>".$row['deliverydate']."</td><td nowrap>".$row['status_name']."</td><td nowrap>".$row['modified_timestamp']."</td></tr>";
			$i++;
		}
 ?>
</table>
<br>
<br>
</p>
</td><td width="30px"></td></tr></table>
</div>
</div>
</td></tr></table>
