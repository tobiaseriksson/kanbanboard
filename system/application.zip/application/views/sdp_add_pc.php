<table><tr><td>
<div class="post">
<div class="content">
<table><tr><td>
<h2 class="title">Add / Modify PC for release</h2>
<p class="meta"><small>xxx</small></p>
<form name="addpc" action="<?php echo site_url( '/sdp/addpc/'.$id ); ?>" method="post">
<input type="hidden" name="pc_id" value="<?php echo $pc_id; ?>" />
<table width="500px">
<tr><td colspan=3>
	<table>
	<tr><td>Release name</td><td><?php echo $header; ?></td></tr>
        <tr><td>PC Number</td><td><input name="pc_number" value="<?php echo $pc_number;?>" type="text" size="45"> </td></tr>
        <tr><td>PC Link</td><td><input name="link" value="<?php echo $link;?>" type="text" size="45"> </td></tr>
        <tr><td>Comment</td><td><input name="comment" value="<?php echo $comment;?>" type="text" size="45"> </td></tr>
	</table>
</td></tr>
<tr><td><br></td></tr>
<tr><td colspan=2>Link given as identification in CDM, e.g. <font color="#ff0000">PC_03202 SDP CS4.0</font><br> in a href like this; http:/ /cdmweb.ericsson.se:7031/TeamCenter/controller/OpenCollection?CollectionName=<font color="#ff0000">PC_03202 SDP CS4.0</font> </td></tr>
<tr><td><br></td></tr>
<tr><td><br></td></tr>
<tr><td></td>
<?php if( $pc_id > 0 ) { ?>
<td align="left"><input name="submit" type="submit" value="Remove" /></td>
<?php } ?>
<td align="right"><input name="submit" type="submit" value="submit" /></td>
</tr>
</table>

</form>
<br>
</p>
</td><td width="30px"></td></tr></table>
</div>
</div>
</td></tr></table>
