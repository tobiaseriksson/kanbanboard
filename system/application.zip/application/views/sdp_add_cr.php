<table><tr><td>
<div class="post">
<div class="content">
<table><tr><td>
<h2 class="title">Add / Modify CR for release</h2>
<p class="meta"><small>xxx</small></p>
<form name="addcr" action="<?php echo site_url( '/sdp/addcr/'.$id ); ?>" method="post">
<input type="hidden" name="cr_id" value="<?php echo $cr_id; ?>" />
<table>
<tr><td colspan=3>
	<table>
	<tr><td>Release name</td><td><?php echo $header; ?></td></tr>
        <tr><td>CR Number</td><td>CR:<input name="cr_number" value="<?php echo $cr_number;?>" type="text" size="5"> </td></tr>
        <tr><td>CR Link</td><td><input name="link" value="<?php echo $link;?>" type="text" size="45"> </td></tr>
        <tr><td>Comment/Title</td><td><input name="comment" value="<?php echo $comment;?>" type="text" size="45"> </td></tr>
	</table>
</td></tr>
<tr><td><br></td></tr>
<tr><td><br></td></tr>
<tr><td><br></td></tr>
<?php if( $cr_id > 0 ) { ?>
<td align="left"><input name="submit" type="submit" value="Remove" /></td>
<?php } ?>
<td align="left"><input name="submit" type="submit" value="submit" /></td>
</tr>
</table>

</form>
<br>
</p>
</td><td width="30px"></td></tr></table>
</div>
</div>
</td></tr></table>

