<table><tr><td>
<div class="post">
<div class="content">
<table><tr><td>
<h2 class="title">TR Followup</h2>
<p class="meta"><small></small></p>
<p>
<A HREF="/sdpfollowup/viewallfollowups_sortby/tr_number">All</A>
<?php
foreach ($teams as $row) {
        echo "<A HREF=\"/sdpfollowup/viewallfollowups_sortby/tr_number/".$row['team']."\">".$row['team']."</A> ";
}
?>
<table cellspacing="0px" class="tr-list">
<tr align="center">
<th>#</th>
<th><A HREF="/sdpfollowup/viewallfollowups_sortby/tr_number/<?php echo $onlyteam; ?>">TR#</A></th>
<th nowrap><strong>Title</strong></th>
<th nowrap><strong>| <A HREF="/sdpfollowup/viewallfollowups_sortby/username/<?php echo $onlyteam; ?>">User</A> | </strong></th>
<th nowrap><strong>| <A HREF="/sdpfollowup/viewallfollowups_sortby/team/<?php echo $onlyteam; ?>">Team</A> | </strong></th>
<th nowrap><strong><A HREF="/sdpfollowup/viewallfollowups_sortby/status/<?php echo $onlyteam; ?>">Status</A> | </strong></th>
<th nowrap><strong><A HREF="/sdpfollowup/viewallfollowups_sortby/prio/<?php echo $onlyteam; ?>">Prio</A> | </strong></th>
<th nowrap><strong>Analysis Started | </strong></th>
<th><strong>TestCase Ready For Review | </strong></th>
<th><strong>TestCase Review Done | </strong></th>
<th nowrap><strong><A HREF="/sdpfollowup/viewallfollowups_sortby/implemented/<?php echo $onlyteam; ?>">Implemented</A></strong> | </th>
<th nowrap><strong>Duration(days) | </strong></th>
<th nowrap><strong>Overdue(A/B/C)</strong></th>
</tr>
<?php

function cleanupDate( $datestring ) {
 if( $datestring == null || strcmp( "0000-00-00", $datestring ) == 0 ) {
      $datestring = "";
 }
 return $datestring;
}


$i=1;
$odd=1;
foreach ($followups as $row)
		{

                        switch( $row['prio'] ) {
                          case 'A':
                               $limit = 14;
                               break;
                          case 'B':
                               $limit = 21;
                               break;
                          case 'c':
                               $limit = 28;
                               break;
                          default:
                               $limit = 28;
                               break;
                        }
                        $overdue = '';
                        if( strlen( trim( $row['age'] ) ) > 0 ) {
                            $overdue = $row['age'] - $limit;
                        }
                        $overdue_textcolor = "color=\"red\"";
                        if( $overdue <= 0 ) $overdue_textcolor = "color=\"green\"";

			if( $odd > 0 ) {
				$tr_class=" class=\"odd\" ";
			} else {
				$tr_class=" class=\"even\" ";
			}
			$opentr_class = "";
			if( strlen( trim( cleanupDate($row['implemented']) ) ) <= 0 ) {
				$row['implemented'] = "OPEN";

				if( $odd > 0 ) {
					$opentr_class=" class=\"odd_open\" ";
				} else {
					$opentr_class=" class=\"even_open\" ";
				}
				if( strcmp( $username, $row['username'] ) == 0 ) {
					$opentr_class = " class=\"open\"";
            	}
			}
			if( strcmp( $username, $row['username'] ) == 0 ) {
				$tr_class=" class=\"alert\" ";
            }
			$title = $row['title'];
			if( strlen( trim( $title ) ) > 50 ) $title = substr( $title, 0, 50 )."...";
			$odd=$odd*-1;
			echo "<tr align=\"center\" ".$tr_class." >";
                        echo "<td>".$i."</td>";
                        echo "<td><a href=\"".site_url( '/sdpfollowup/addormodify/'.$row['tr_number'] )."\">".$row['tr_number']."</a></td>";
                        echo "<td align=\"left\" nowrap>".$title."</td>";
                        echo "<td>".$row['username']."</td>";
                        echo "<td>".$row['team']."</td>";
                        echo "<td>".$row['status']."</td>";
                        echo "<td>".$row['prio']."</td>";
                        echo "<td nowrap>".cleanupDate($row['analysis_started'])."</td>";
                        echo "<td nowrap>".cleanupDate($row['testcase_ready_for_review'])."</td>";
                        echo "<td nowrap>".cleanupDate($row['testcase_review_done'])."</td>";
                        echo "<td nowrap ".$opentr_class.">".cleanupDate($row['implemented'])."</td>";
                        echo "<td nowrap>".$row['age']."</td>";
                        echo "<td nowrap><font $overdue_textcolor>$overdue</font></td>";
                        echo "</tr>";
			$i++;
		}
 ?>
</table>
<br>
<br>
</p>
</td><td width="30px"></td></tr></table>
</div>
</div>
</td></tr></table>

