<table><tr><td>
<div class="post">
<div class="content">
<table width="500px"><tr><td>
<h2 class="title">SDP TR Team Followup Statistics</h2>
<p class="meta"><small></small></p>
<p>Here you can see all the TRs that been worked on grouped by Team and Week
<p>
<table cellspacing="0px" class="tr-list">
<tr><th>#</th><th width="100px">Week</th><th width="200px">Team</th><th width="100px">Solved TRs</th></tr>
<?php 
$i=1;
$odd=1;
foreach ($stats as $row)
		{
			if( $odd > 0 ) {
				$tr_class=" class=\"odd\" ";
			} else {
				$tr_class=" class=\"even\" ";
			}
			$odd=$odd*-1;
			echo "<tr ".$tr_class." ><td>".$i."</td><td align=\"left\">".$row['year_and_week']."</td><td align=\"center\">".$row['team']."</td><td align=\"right\">".$row['total']."</td></tr>";
			$i++;
		}
 ?>
</table>
<br>
<br>
</p>
</td><td width="30px"></td></tr></table>
</div>
</div>
</td></tr></table>

<table><tr><td>
<div class="post">
<div class="content">
<table width="500px"><tr><td>
<h2 class="title">SDP TR Team Followup Statistics</h2>
<p class="meta"><small></small></p>
<p>Here you can see all the TRs that been worked on grouped by Team and Week
<p>
<table cellspacing="0px" class="tr-list">
<tr><th>#</th><th width="100px">Month</th><th width="200px">Team</th><th width="100px">Solved TRs</th></tr>
<?php 
$i=1;
$odd=1;
foreach ($monthstats as $row)
		{
			if( $odd > 0 ) {
				$tr_class=" class=\"odd\" ";
			} else {
				$tr_class=" class=\"even\" ";
			}
			$odd=$odd*-1;
			echo "<tr ".$tr_class." ><td>".$i."</td><td align=\"left\">".$row['year_and_month']."</td><td align=\"center\">".$row['team']."</td><td align=\"right\">".$row['total']."</td></tr>";
			$i++;
		}
 ?>
</table>
<br>
<br>
</p>
</td><td width="30px"></td></tr></table>
</div>
</div>
</td></tr></table>

