<table><tr><td>
<div class="post">
<div class="content">
<h2 class="title">Add / Modify TR Followup</h2>
<p class="meta"><small></small></p>
<div class="errortext"><?php echo $errormessage; ?></div>
<br>
<form name="addormodifytrfollowup" action="<?php echo site_url( '/sdpfollowup/addormodify/'.$id); ?>" method="post">
<input type="hidden" name="id" value="<?php echo $id; ?>" />
<table>
<tr><td colspan=4>
	<table>
<?php 
if( $id > 0 ) {
  $trurl="http://mhweb.ericsson.se/mhweb/servlet/tredit?action=REFRESH&eriref=".$tr_number;
?>
        <tr><td nowrap><strong>TR Number</strong></td><td><input type="hidden" name="tr_number" size="30" value="<?php echo $tr_number; ?>"><a href="<?php echo $trurl; ?>"><?php echo $tr_number; ?></a> <input type="submit" value="Delete" name="Delete" /></td></tr>
        <tr><td><strong>TR Title</strong></td><td><?php echo $title; ?></td></tr>
        <tr><td><strong>TR Status</strong></td><td><?php echo $status; ?></td></tr>
        <tr><td><strong>TR Prio</strong></td><td><?php echo $prio; ?></td></tr>
        <tr><td><strong>Developer</strong></td><td><?php echo form_dropdown('username', $usernamearray, $username); ?></td></tr>
        <tr><td valign="top"><strong>Target Release/Branch</strong></td><td>
<table>
<tr>
<td>Release</td>
<td>Branch</td>
<td>Added to Release</td>
</tr>
<?php
$i=1;
$odd=1;
foreach ($releases as $row)
{
        if( $odd > 0 ) {
	  $tr_class=" class=\"odd\" ";
	} else {
	  $tr_class=" class=\"even\" ";
	}
	$odd=$odd*-1;
        echo "<tr ".$tr_class." >";
	echo "<td><a href=\"/sdp/viewrelease/".$row['release_id']."\">".$row['header']."</a></td>";
	echo "<td>".$row['branch']."</td>";
	echo "<td>".$row['submitted']."</td>";
}
?>
</table>
</td></tr>
<?php
} else {
?>
        <tr><td nowrap><strong>TR Number</strong></td><td><input type="text" name="tr_number" size="30" value="<?php echo $tr_number; ?>"></td></tr>
        <tr><td><strong>Developer</strong></td><td><?php echo form_dropdown('username', $usernamearray, $username); ?></td></tr>
<?php
}
?>

	<tr><td valign="top"><strong>Comment</strong></td><td><textarea name="comment" cols="80" rows="15"><?php echo $comment;?></textarea></td></tr>
	</table>
</td></tr>
<tr><td><br></td></tr>
<tr align="center"><td><strong>Analysis Started</strong></td><td><strong>TestCase Ready For Review</strong></td><td><strong>TestCase Review Done</strong></td><td><strong>Implemented</strong></td></tr>
<tr align="center">
<td>
<?php echo js_calendar_write('analysis_started', $analysis_started_time, true);?>
<input type="text" name="analysis_started" value="<?php echo $analysis_started; ?>" onblur="update_calendar(this.name, this.value);" size="9"/>
<p><a href="javascript:void(0);" onClick="set_to_time('analysis_started', '<?php echo time();?>')" >Today</a></p>
</td>
<td>
<?php echo js_calendar_write('testcase_ready_for_review', $testcase_ready_for_review_time, true);?>
<input type="text" name="testcase_ready_for_review" value="<?php echo $testcase_ready_for_review; ?>" onblur="update_calendar(this.name, this.value);" size="9"/>
<p><a href="javascript:void(0);" onClick="set_to_time('testcase_ready_for_review', '<?php echo time();?>')" >Today</a></p>
</td>
<td>
<?php echo js_calendar_write('testcase_review_done', $testcase_review_done_time, true);?>
<input type="text" name="testcase_review_done" value="<?php echo $testcase_review_done; ?>" onblur="update_calendar(this.name, this.value);" size="9"/>
<p><a href="javascript:void(0);" onClick="set_to_time('testcase_review_done', '<?php echo time(); ?>')" >Today</a></p>
</td>
<td>
<?php echo js_calendar_write('implemented', $implemented_time, true);?>
<input type="text" name="implemented" value="<?php echo $implemented; ?>" onblur="update_calendar(this.name, this.value);" size="9"/>
<p><a href="javascript:void(0);" onClick="set_to_time('implemented', '<?php echo time(); ?>')" >Today</a></p>
</td>
</tr>
<tr>
<td valign="top" width="150px">The definition of Analysis Started is when the developer takes ownership of a TR / starts the investigation</td>
<td valign="top" width="150px">The definition of Test Case Ready For Review is that there exist one or several Test Cases that clearly proves the existance of the problem described in the TR and that the problem is solved.</td>
<td valign="top" width="150px">The defintion of Test Case Review Done is when LSV has reviwed and accepted the Test Case implementation</td>
<td valign="top" width="150px">The definition for Implemented, means when the TR solution, and Test Case(s) has been implemented / Committed and the regression suite is confirmed GREEN on the integration branch.</td>
<tr><td> </td></tr>
<tr><td colspan=4 align="right"><input name="submit" type="submit" value="submit" /></td><td width="30px"></td></tr>
</table>
</form>
<br>
</p>
</div>
</div>
</td>
</tr>
</table>


<table><tr><td>
<div class="post">
<div class="content">
<h2 class="title">Followup History</h2>
<p class="meta"><small>xxx</small></p>
<table><tr><td width="750px">

<table>
<?php
foreach ($history as $row) {
echo "<tr><td nowrap><small>".$row['submitted']."</td><td>".$row['submitted_by']."</small></td></tr>";
echo "<tr><td></td><td>".nl2br($row['message'])."</td></tr>\n";
echo "<tr><td><br></td></tr>\n";
}

?>
</table>


</td><td width="30px"></td></tr>
</td>
</tr>
</table>