<table><tr><td>
<div class="post">
<div class="content">
<table><tr><td>
<h2 class="title"><?php echo $header; ?></h2>
<p class="meta"><small>Last modified; <?php echo $modified_timestamp." by ".$modified_by;?></small></p>
<a href="<?php echo site_url( '/sdp/editrelease/'.$id); ?>">Edit Release Information</a>
<br>
<br>
<form name="viewrelease" action="<?php echo site_url( '/sdp/viewrelease/'.$id); ?>" method="post">
<input type="hidden" name="id" value="<?php echo $id; ?>" />
<table>
<tr><td colspan=3>
	<table>
	<tr><td><strong>Branch</strong></td><td><?php echo $branch; ?></td><td></td><td></td></tr>
	<tr><td><strong>Status</strong></td><td><?php echo $release_status; ?></td><td></td><td></td></tr>
	<tr><td valign="top"><strong>Comment</strong></td><td colspan=4 width="300px" bgcolor="#CCCCCC"><em><?php echo nl2br($comment);?></em></td></tr>
	<tr><td><strong>Complementary<br>Release<br>Content</strong></td><td valign="top">
	<table><tr><td>Name</td><td>Branch</td><td>Code Freeze</td></tr>
<?php
foreach ($child_releases as $row)
	echo "<tr><td><A HREF=\"".site_url( '/sdp/viewrelease/'.$row['id'])."\">".$row['header']."</A></td><td>".$row['branch']."</td><td>".$row['codefreeze']."</td></tr>";
?>
	</table>
	<td></tr>
	</table>
</td></tr>
<tr><td><br></td></tr>
<tr align="center"><td><strong>Content Freeze</strong></td><td><strong>Code Freeze</strong></td><td><strong>LSV Delivery Date</strong></td><td><strong>Delivery Date</strong></td></tr>
<tr align="center">
<td>
<?php echo js_calendar_write('contentfreeze', $contentfreeze_time, true);?>
<input type="hidden" name="contentfreeze" value="<?php echo $contentfreeze; ?>" onblur="update_calendar(this.name, this.value);" size="8"/>
<?php echo $contentfreeze; ?>
<?php echo " Week ".date( "W", $contentfreeze_time); ?>
</td>
<td>
<?php echo js_calendar_write('codefreeze', $codefreeze_time, true);?>
<input type="hidden" name="codefreeze" value="<?php echo $codefreeze; ?>" onblur="update_calendar(this.name, this.value);" size="8"/>
<?php echo $codefreeze; ?>
<?php echo " Week ".date( "W", $codefreeze_time); ?>
</td>
<td>
<?php echo js_calendar_write('lsvdeliverydate', $lsvdeliverydate_time, true);?>
<input type="hidden" name="deliverydate" value="<?php echo $lsvdeliverydate; ?>" onblur="update_calendar(this.name, this.value);" size="8"/>
<?php echo $lsvdeliverydate; ?>
<?php echo " Week ".date( "W", $lsvdeliverydate_time); ?>
</td>
<td>
<?php echo js_calendar_write('deliverydate', $deliverydate_time, true);?>
<input type="hidden" name="deliverydate" value="<?php echo $deliverydate; ?>" onblur="update_calendar(this.name, this.value);" size="8"/>
<?php echo $deliverydate; ?>
<?php echo " Week ".date( "W", $deliverydate_time); ?>
</td>
</tr>
</table>
</form>
<p></p>
<br>
</p>
<br>
</td><td width="30px"></td></tr></table>
</div>
</div>
</td></tr></table>

<table><tr><td>
<div class="post">
<div class="content">
<table><tr><td>
<br>
<br>
<a href="<?php echo site_url( '/sdp/addtrs/'.$id); ?>">Add TRs</a> |
<a href="<?php echo site_url( '/sdp/confirmtrs/'.$id); ?>">Confirm TRs</a> |
<a href="<?php echo site_url( '/sdp/deletetrs/'.$id); ?>">Delete TRs</a> |
<a href="<?php echo site_url( '/sdp/tagtrs/'.$id); ?>">Tag TRs</a> |
<a href="<?php echo site_url( '/sdp/movetrs/'.$id); ?>">Move TRs</a>
<h2>List of included TRs</h2>
<table cellspacing="0px" class="tr-list">
<tr>
<th>#</th>
<th><a href="<?php echo site_url( '/sdp/viewrelease/'.$id); ?>/5">OK</a></th>
<th><a href="<?php echo site_url( '/sdp/viewrelease/'.$id); ?>/0">TR#</a></th>
<th><a href="<?php echo site_url( '/sdp/viewrelease/'.$id); ?>/2">Tag</a></th>
<th>Title</th>
<th><a href="<?php echo site_url( '/sdp/viewrelease/'.$id); ?>/4">Prio</a></th>
<th><a href="<?php echo site_url( '/sdp/viewrelease/'.$id); ?>/3">Status</a></th>
<th><a href="<?php echo site_url( '/sdp/viewrelease/'.$id); ?>/7">Answer</a></th>
<th><a href="<?php echo site_url( '/sdp/viewrelease/'.$id); ?>/6">Registred</a></th>
<th>Comment</th>
<th><a href="<?php echo site_url( '/sdp/viewrelease/'.$id); ?>/1">Added By</a></th>
</tr>
<?php 
$i=1;
$odd=1;
foreach ($trs as $row)
		{
			if( $odd > 0 ) {
				$tr_class=" class=\"odd\" ";
			} else {
				$tr_class=" class=\"even\" ";
			}
			$odd=$odd*-1;

			$checked = "";
			if( $row['confirmed_ok'] > 0 ) $checked = "CHECKED";
##			else {
##			$tr_class=" class=\"alert\" ";
##			}
			$deleted_start = "";
			$deleted_end = "";
			if( $row['deleted'] > 0 ) {
				$deleted_start = "<del>";
				$deleted_end = "</del>";
			}
			// id,tr_number,submited_by,confirmed_ok
			echo "<tr ".$tr_class." >";
			echo "<td>".$i."</td>";
			echo "<td><input type=\"checkbox\" name=\"confirmed[]\" value=\"".$row['tr_number']."\" ".$checked.">";
			$trurl="http://mhweb.ericsson.se/mhweb/servlet/tredit?action=REFRESH&eriref=".$row['tr_number'];
			echo "</td><td><a href=\"".$trurl."\">".$deleted_start."".$row['tr_number']."".$deleted_end."</a></td>";
			echo "<td>".$row['tag']."</td>";
			echo "<td nowrap>".substr($row['title'],0,70)."</td>";
			echo "<td>".$row['prio']."</td>";
			echo "<td>".$row['status']."</td>";
			echo "<td>".$row['answer']."</td>";
			echo "<td>".$row['registred']."</td>";
			echo "<td nowrap><a href=\"".site_url( '/sdp/trspecificcomment/'.$id.'/'.$row['id'] )."\">+</a>".substr($row['comment'],0,50)."</td>";
			echo "<td nowrap>".$row['submitted']."(".$row['submitted_by'].")</td>";
			echo "</tr>\n";
			$i++;
		}
## 
## Now include Child-Release-TRs
## 
$child_release_id = 0;
foreach ($child_trs as $row)
		{
			if( $odd > 0 ) {
				$tr_class=" class=\"odd\" ";
			} else {
				$tr_class=" class=\"even\" ";
			}
			$odd=$odd*-1;

			if( $child_release_id != $row['release_id'] ) {
				echo "<tr ".$tr_class." >";
				echo "<td></td>";
				echo "<td></td>";
				echo "<td></td>";				
				echo "<td></td>";
				echo "<td nowrap><h3>".substr($row['header'],0,70)."</h3></td>";
				echo "<td></td>";
				echo "<td></td>";
				echo "<td></td>";		
				echo "<td></td>";
				echo "<td></td>";
				echo "<td></td>";		
				echo "</tr>";
				$child_release_id = $row['release_id'];
				if( $odd > 0 ) {
					$tr_class=" class=\"odd\" ";
				} else {
					$tr_class=" class=\"even\" ";
				}
				$odd=$odd*-1;
			}

			$checked = "";
			if( $row['confirmed_ok'] > 0 ) $checked = "CHECKED";
##			else {
##			$tr_class=" class=\"alert\" ";
##			}
			$deleted_start = "";
			$deleted_end = "";
			if( $row['deleted'] > 0 ) {
				$deleted_start = "<del>";
				$deleted_end = "</del>";
			}
			// id,tr_number,submited_by,confirmed_ok
			echo "<tr ".$tr_class." >";
			echo "<td>".$i."</td>";
			echo "<td><input type=\"checkbox\" name=\"confirmed[]\" value=\"".$row['tr_number']."\" ".$checked.">";
			$trurl="http://mhweb.ericsson.se/mhweb/servlet/tredit?action=REFRESH&eriref=".$row['tr_number'];
			echo "</td><td><a href=\"".$trurl."\">".$deleted_start."".$row['tr_number']."".$deleted_end."</a></td>";
			echo "<td>".$row['tag']."</td>";
			echo "<td nowrap>".substr($row['title'],0,70)."</td>";
			echo "<td>".$row['prio']."</td>";
			echo "<td>".$row['status']."</td>";
			echo "<td>".$row['answer']."</td>";
			echo "<td>".$row['registred']."</td>";
			echo "<td nowrap><a href=\"".site_url( '/sdp/trspecificcomment/'.$id.'/'.$row['id'] )."\">+</a>".substr($row['comment'],0,50)."</td>";
			echo "<td nowrap>".$row['submitted']."(".$row['submitted_by'].")</td>";
			echo "</tr>\n";
			$i++;
		} 
?>
</table>



<br>
</p>
<br>
</td><td width="30px"></td></tr></table>
</div>
</div>
</td></tr></table>

<table><tr><td>
<div class="post">
<div class="content">
<table><tr><td>
<br>
<br>
<a href="<?php echo site_url( '/sdp/adddocument/'.$id); ?>">Add Files and Documents</a>
<h2>List of included Files and Documents</h2>
<table cellspacing="0px" class="tr-list"
<?php
      if( count( $docs ) <= 0 ) echo "width=\"800px\" ";
?>
>
<tr><th>#</th><th>Doc Number</th><th></th><th>Rev</th><th>Comment</th><th>Added By</th><th>Action</th>
</tr>
<?php 
$i=1;
$odd=1;
foreach ($docs as $row)
{
	if( $odd > 0 ) {
		$tr_class=" class=\"odd\" ";
	} else {
		$tr_class=" class=\"even\" ";
	}
	$odd=$odd*-1;

	// id,tr_number,submited_by,confirmed_ok
	echo "<tr ".$tr_class." >";
	echo "<td>".$i."</td>";
	$doc_number_with_no_spaces = preg_replace( '/\s*/m', '', $row['doc_number'] );
	$gask_url = "http://gask2web.ericsson.se/pub/get?DocNo=".$doc_number_with_no_spaces."&Lang=EN&Rev=".$row['doc_revision']."&Format=PDFV1R2";
	$cdm_url = "http://cdmweb.ericsson.se/WEBLINK/ViewDocs?DocumentName=".$doc_number_with_no_spaces."&Latest=true";
	echo "<td>".$row['doc_number']."</td>";
	echo "<td><a href=\"".$gask_url."\">GASK</a> <a href=\"".$cdm_url."\">CDM</a></td>";
	echo "<td>".$row['doc_revision']."</td>";
	echo "<td>".$row['comment']."</td>";
	echo "<td>".$row['submitted_by']." ".$row['submitted']."</td>";
	echo "<td><a href=\"".site_url( '/sdp/modifydocument/'.$id.'/'.$row['id'] )."\">Modify</a></td>";
	echo "</tr>\n";
	$i++;
} 

##
## Now include any Docs/Files from Child-Releases
## 
$child_release_id = 0;
foreach ($childdocs as $row)
{
	if( $odd > 0 ) {
		$tr_class=" class=\"odd\" ";
	} else {
		$tr_class=" class=\"even\" ";
	}
	$odd=$odd*-1;

	if( $child_release_id != $row['release_id'] ) {
		echo "<tr ".$tr_class." >";
		echo "<td></td>";
		echo "<td colspan=6 nowrap><h3>".substr($row['header'],0,70)."</h3></td>";
		echo "</tr>";
		$child_release_id = $row['release_id'];
		if( $odd > 0 ) {
			$tr_class=" class=\"odd\" ";
		} else {
			$tr_class=" class=\"even\" ";
		}
		$odd=$odd*-1;
	}
	// id,tr_number,submited_by,confirmed_ok
	echo "<tr ".$tr_class." >";
	echo "<td>".$i."</td>";
	$doc_number_with_no_spaces = preg_replace( '/\s*/m', '', $row['doc_number'] );
	$gask_url = "http://gask2web.ericsson.se/pub/get?DocNo=".$doc_number_with_no_spaces."&Lang=EN&Rev=".$row['doc_revision']."&Format=PDFV1R2";
	$cdm_url = "http://cdmweb.ericsson.se/WEBLINK/ViewDocs?DocumentName=".$doc_number_with_no_spaces."&Latest=true";
	echo "<td>".$row['doc_number']."</td>";
	echo "<td><a href=\"".$gask_url."\">GASK</a> <a href=\"".$cdm_url."\">CDM</a></td>";
	echo "<td>".$row['doc_revision']."</td>";
	echo "<td>".$row['comment']."</td>";
	echo "<td>".$row['submitted_by']." ".$row['submitted']."</td>";
	echo "<td><a href=\"".site_url( '/sdp/modifydocument/'.$id.'/'.$row['id'] )."\">Modify</a></td>";
	echo "</tr>\n";
	$i++;
} 


?>
</table>


<br>
</td><td width="30px"></td></tr></table>
</div>
</div>
</td></tr></table>

<table><tr><td>
<div class="post">
<div class="content">
<table><tr><td>
<br>
<br>
<a href="/sdp/addpc/<?php echo $id; ?>">Add PC</a>
<h2>List of included PCs</h2>
<table cellspacing="0px" class="tr-list" 
<?php
      if( count( $pcs ) <= 0 ) echo "width=\"800px\" ";
?>
>
<tr><th>#</th><th>PC Number</th><th>Comment</th><th>Added By</th><th>Action</th>
</tr>
<?php 
$i=1;
$odd=1;
foreach ($pcs as $row)
		{
			if( $odd > 0 ) {
				$tr_class=" class=\"odd\" ";
			} else {
				$tr_class=" class=\"even\" ";
			}
			$odd=$odd*-1;

			// id,tr_number,submited_by,confirmed_ok
			echo "<tr ".$tr_class." >";
			echo "<td>".$i."</td>";
			$pc_url="http://cdmweb.ericsson.se:7031/TeamCenter/controller/OpenCollection?CollectionName=".$row['link'];
			echo "<td><a href=\"".$pc_url."\">PC".$row['pc_number']."</a></td>";
                        echo "<td>".$row['comment']."</td>";
			echo "<td>".$row['submitted_by']." ".$row['submitted']."</td>";
			echo "<td><a href=\"/sdp/modifypc/$id/".$row['id']."\">Modify</a></td>";
			echo "</tr>\n";
			$i++;
		} 
?>
</table>
</td><td width="30px"></td></tr></table>
</div>
</div>
</td></tr></table>

<table><tr><td>
<div class="post">
<div class="content">
<table><tr><td>
<br>
<br>
<a href="/sdp/addcr/<?php echo $id; ?>">Add CR</a>
<h2>List of included CRs</h2>
<table cellspacing="0px" class="tr-list"
<?php
      if( count( $crs ) <= 0 ) echo "width=\"800px\" ";
?>
>
<tr><th>#</th><th>CR Number</th><th>Title/Comment</th><th>Added By</th><th>Action</th>
</tr>
<?php 
$i=1;
$odd=1;
foreach ($crs as $row)
		{
			if( $odd > 0 ) {
				$tr_class=" class=\"odd\" ";
			} else {
				$tr_class=" class=\"even\" ";
			}
			$odd=$odd*-1;

			// id,tr_number,submited_by,confirmed_ok
			echo "<tr ".$tr_class." >";
			echo "<td>".$i."</td>";
			$cr_url="http://cdmweb.ericsson.se:7031/TeamCenter/controller/OpenCollection?CollectionName=".$row['link'];
			echo "<td><a href=\"".$cr_url."\">CR".$row['cr_number']."</a></td>";
                        echo "<td>".$row['comment']."</td>";
			echo "<td>".$row['submitted_by']." ".$row['submitted']."</td>";
			echo "<td><a href=\"/sdp/modifycr/$id/".$row['id']."\">Modify</a></td>";
			echo "</tr>\n";
			$i++;
		} 
?>
</table>
</td><td width="30px"></td></tr></table>
</div>
</div>
</td></tr></table>

<table><tr><td>
<div class="post">
<div class="content">
<table><tr><td>
<h2>History</h2>
<table>
<?php
foreach ($history as $row) {
echo "<tr><td nowrap><small>".$row['submitted']."</td><td>".$row['submitted_by']."</small></td></tr>";
echo "<tr><td></td><td>".nl2br($row['message'])."</td></tr>\n";
echo "<tr><td><br></td></tr>\n";
}

?>
</table>
</td><td width="30px"></td></tr></table>
</div>
</div>
</td></tr></table>
