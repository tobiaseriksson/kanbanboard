<table><tr><td>
<div class="post">
<div class="content">
<table><tr><td>
<h2 class="title">RSS Feeds for SDP ICP Content </h2>
<p class="meta">&nbsp;</p>
<p>Currently the following RSS Feeds exists</p>

<p>* <a href="<?php echo site_url( '/feed/anychange' ); ?>">Any Change</a>, this will inform you about any change in any release </p>
<p>* <a href="<?php echo site_url( '/feed/deleted' ); ?>">Deleted content</a>, this will inform you about all the items that has been deleted from a release </p>
<p>
<br>
<br>
</p>
</td><td width="30px"></td></tr></table>
</div>
</div>
</td></tr></table>
