<table><tr><td>
<div class="post">
<div class="content">
<table><tr><td>
<h2 class="title">Link Child Releases With THIS Release</h2>
<p class="meta"><small>The intention with the child releases is that sometimes a release is about to go out but then in the last minute there are problems that require us to create a so called GLOBAL EP, therefore it is important to include these child-releases in here to track where the releases go.<br><br>
bla bla bla</small></p>
<form name="tagtrs" action="<?php echo site_url( '/sdp/editcomplementaryreleases/'.$id); ?>" method="post">
<input type="hidden" name="id" value="<?php echo $id; ?>" />
<input type="hidden" name="header" value="<?php echo $header; ?>" />
<table>
<tr><td colspan=3>
	<table>
	<tr><td>Release name</td><td><?php echo $header; ?></td></tr>
	</table>
</td></tr>
<tr><td><br></td></tr>
<tr><td><br></td></tr>

<tr><td>

<table cellspacing="0px" class="tr-list">
<tr><th>#</th><th>Release</th><th>Status</th><th>Belongs to THIS Release</th></tr>
<?php 
$i=1;
$odd=1;
foreach ($releases as $row)
		{
			if( $odd > 0 ) {
				$tr_class=" class=\"odd\" ";
			} else {
				$tr_class=" class=\"even\" ";
			}
			$odd=$odd*-1;

			$checked = "";
			if( array_key_exists( $row['id'], $linked_releases ) ) $checked = "CHECKED";
			
			echo "<tr ".$tr_class." ><td>".$i."</td><td><a href=\"".site_url( '/sdp/viewrelease/'.$row['id'] )."\">".$row['header']."</a></td><td>".$row['status_name']."</td><td align=\"center\"><input type=\"checkbox\" name=\"childrelease[]\" value=\"".$row['id']."\" ".$checked."></td></tr>\n";
			$i++;
		}
?>
</table>


</td></tr>
<tr><td><br></td></tr>
<tr><td colspan=3 align="right"><input name="submit" type="submit" value="submit" /></td></tr>
</table>

</form>
<br>
</p>
</td><td width="30px"></td></tr></table>
</div>
</div>
</td></tr></table>
