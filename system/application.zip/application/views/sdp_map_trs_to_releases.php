<table><tr><td>
<div class="post">
<div class="content">
<table><tr><td>
<h2 class="title">Map TRs to Releases (branches) </h2>
<p class="meta"><small></small></p>
<table cellspacing="0px" class="tr-list">
<?php
$odd = 1;
$index = 1;
foreach ($listOfTrs as $key => $value) {
	if( $odd > 0 ) {
		$tr_class=" class=\"odd\" ";
	} else {
		$tr_class=" class=\"even\" ";
	}
	$odd=$odd*-1;
	echo "<tr $tr_class><td valign=\"top\">$index</td><td valign=\"top\">$key</td><td>$value</td></tr>\n";
	$index = $index + 1;
}
?>
</table>
</td><td width="30px"></td></tr></table>
</div>
</div>
</td></tr></table>
