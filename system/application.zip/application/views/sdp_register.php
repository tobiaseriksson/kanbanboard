<table><tr><td>
<div class="post">
<div class="content">
<table><tr><td>
<h2 class="title">Register</h2>
<div class="errortext">
<?php echo validation_errors(); ?>
<?php echo $errormessage."<br>"; ?>
</div>
<form name="register" action="<?php echo site_url( '/sdp/register' ); ?>" method="post">
<input type="hidden" name="id" value="0" />
  <table>
<tr><td>e-mail</td><td><input type="text" name="email" value="<?php echo set_value('email'); ?>" size="15"></td></tr>
<tr><td>username</td><td><input type="text" name="username" value="<?php echo set_value('username'); ?>" size="15"> your Ericsson-ID, e.g. etobier</td></tr>
<tr><td>team</td><td><input type="text" name="team" value="<?php echo set_value('team'); ?>" size="15"> e.g. team7,support,none

<select name="teamselection" onChange="document.register.team.value = this.options[this.selectedIndex].text;">
<?php
$i=1;
foreach ($teamarray as $row) {
        echo "<option value=\"".$i."\">".$row."</option>\n";
        $i++;
}
?>
</select>
</td></tr>
<tr><td>password</td><td><input type="password" name="password" value="<?php echo set_value('password'); ?>" size="15"> (stored with MD5 encryption)</td></tr>
<tr><td>repeat password</td><td><input type="password" name="password2" value="<?php echo set_value('password2'); ?>" size="15"></td></tr>
<tr><td></td><td align="right"><input type="submit" name="register" value="register"></td></tr>
</table>
</form>
<br>
</p>
</td><td width="30px"></td></tr>
</table>
</div>
</div>
</td>
</tr></table>
