<table><tr><td>
<div class="post">
<div class="content">
<table><tr><td>
<h2 class="title">SDP ICP Content Page </h2>
<p class="meta"><small></small></p>
<p>Here are all ongoing releases, to see the complete list including those allready delivered or canceled please click <a href="/sdp/viewreleases">View All Releases</a>.</p>
<p>
<table cellspacing="0px" class="tr-list">
<tr><th>#</th><th>Name</th><th>Delivery Date</th><th>Status</th><th>Modified</th></tr>
<?php 
$i=1;
$odd=1;
foreach ($releases as $row)
		{
			if( $odd > 0 ) {
				$tr_class=" class=\"odd\" ";
			} else {
				$tr_class=" class=\"even\" ";
			}
			$odd=$odd*-1;
			echo "<tr ".$tr_class." ><td>".$i."</td><td><a href=\"".site_url( '/sdp/viewrelease/'.$row['id'] )."\">".$row['header']."</a></td><td>".$row['deliverydate']."</td><td>".$row['status_name']."</td><td>".$row['modified_timestamp']."</td></tr>";
			$i++;
		}
 ?>
</table>
<br>
<br>
</p>
</td><td width="30px"></td></tr></table>
</div>
</div>
</td></tr></table>

