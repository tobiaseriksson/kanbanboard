<table><tr><td>
<div class="post">
<div class="content">
<table><tr><td>
<h2 class="title">Add Release / Package to the SDP ICP Content plan</h2>
<p class="meta"><small>xxx</small></p>
<form name="addrelease" action="<?php echo site_url( '/sdp/modifyrelease/'.$id); ?>" method="post">
<input type="hidden" name="id" value="<?php echo $id; ?>" />
<table>
<tr><td colspan=3>
	<table>
	<tr><td><strong>Release name</strong></td><td><input type="text" name="header" size="30" value="<?php echo $header; ?>"></td></tr>
	<tr><td><strong>Branch</strong></td><td><input type="text" name="branch" size="30" value="<?php echo $branch; ?>"></td></tr>
	<tr><td><strong>Status</strong></td><td><?php echo form_dropdown('status', $statusarray, $status); ?></td></tr>
	<tr><td><strong>Comment</strong></td></tr>
	<tr><td colspan=2><textarea name="comment" cols="50" rows="5"><?php echo $comment;?></textarea></td></tr>
	<tr><td><strong>Complementary<br>Release<br>Content</strong></td><td valign="top"><a href="<?php echo site_url( '/sdp/editcomplementaryreleases/'.$id ); ?>">Edit Complementart Releases</a><br>
	<table><tr><td>Name</td><td>Branch</td><td>Code Freeze</td></tr>
<?php
foreach ($child_releases as $row)
	echo "<tr><td><A HREF=\"".site_url( '/sdp/viewrelease/'.$row['id'])."\">".$row['header']."</A></td><td>".$row['branch']."</td><td>".$row['codefreeze']."</td></tr>";
?>
	</table>
	<td></tr>
	</table>
</td></tr>
<tr><td><br></td></tr>
<tr align="center"><td><strong>Content Freeze</strong></td><td><strong>Code Freeze</strong></td><td><strong>LSV Delivery Date</strong></td><td><strong>Delivery Date</strong></td></tr>
<tr align="center">
<td>
<?php echo js_calendar_write('contentfreeze', $contentfreeze_time, true);?>
<input type="text" name="contentfreeze" value="<?php echo $contentfreeze; ?>" onblur="update_calendar(this.name, this.value);" size="8"/>
<p><a href="javascript:void(0);" onClick="set_to_time('contentfreeze', '<?php echo time();?>')" >Today</a></p>
</td>
<td>
<?php echo js_calendar_write('codefreeze', $codefreeze_time, true);?>
<input type="text" name="codefreeze" value="<?php echo $codefreeze; ?>" onblur="update_calendar(this.name, this.value);" size="8"/>
<p><a href="javascript:void(0);" onClick="set_to_time('codefreeze', '<?php echo time();?>')" >Today</a></p>
</td>
<td>
<?php echo js_calendar_write('lsvdeliverydate', $lsvdeliverydate_time, true);?>
<input type="text" name="lsvdeliverydate" value="<?php echo $lsvdeliverydate; ?>" onblur="update_calendar(this.name, this.value);" size="8"/>
<p><a href="javascript:void(0);" onClick="set_to_time('lsvdeliverydate', '<?php echo time(); ?>')" >Today</a></p>
</td>
<td>
<?php echo js_calendar_write('deliverydate', $deliverydate_time, true);?>
<input type="text" name="deliverydate" value="<?php echo $deliverydate; ?>" onblur="update_calendar(this.name, this.value);" size="8"/>
<p><a href="javascript:void(0);" onClick="set_to_time('deliverydate', '<?php echo time(); ?>')" >Today</a></p>
</td>
</tr>
<tr><td colspan=4 align="right"><input name="submit" type="submit" value="submit" /></td></tr>
</table>

</form>
<br>
</p>
</td><td width="30px"></td></tr></table>
</div>
</div>
</td></tr></table>

