<table><tr><td>
<div class="post">
<div class="content">
<table><tr><td>
<h2 class="title">Confirm / Unconfirm TRs for release</h2>
<p class="meta"><small>To Confirm a TR means that we are certain that it has been implemented for this release (in this branch).</small></p>
<form name="confirmtrs" action="<?php echo site_url( '/sdp/confirmtrs/'.$id); ?>" method="post">
<input type="hidden" name="id" value="<?php echo $id; ?>" />
<input type="hidden" name="header" value="<?php echo $header; ?>" />
<table>
<tr><td colspan=3>
	<table>
	<tr><td>Release name</td><td><?php echo $header; ?></td></tr>
	</table>
</td></tr>
<tr><td><br></td></tr>
<tr><td>

<table cellspacing="0px" class="tr-list">
<tr><th>#</th><th>TR#</th><th>Added By</th><th>Confirmed</th></tr>
<?php 
$i=1;
$odd=1;
foreach ($trs as $row)
		{
			if( $odd > 0 ) {
				$tr_class=" class=\"odd\" ";
			} else {
				$tr_class=" class=\"even\" ";
			}
			$odd=$odd*-1;

			$checked = "";
			if( $row['confirmed_ok'] > 0 ) $checked = "CHECKED";
						
			// id,tr_number,submited_by,confirmed_ok
			echo "<tr ".$tr_class." ><td>".$i."</td><td><a href=\"".site_url( '/sdp/viewtr/')."".$row['id']."\">".$row['tr_number']."</a></td><td>".$row['submitted_by']."</td><td><input type=\"checkbox\" name=\"confirmed[]\" value=\"".$row['id']."\" ".$checked."></td></tr>\n";
			$i++;
		}
?>
</table>


</td></tr>
<tr><td><br></td></tr>
<tr><td colspan=3 align="right"><input name="submit" type="submit" value="submit" /></td></tr>
</table>

</form>
<br>
</p>
</td><td width="30px"></td></tr></table>
</div>
</div>
</td></tr></table>

