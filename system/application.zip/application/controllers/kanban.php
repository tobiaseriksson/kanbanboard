<?php

class kanban extends Controller {

    function kanban()    {
        parent::Controller();   
		$this->load->database();     
		$this->load->helper('xml');    
		$this->load->helper('url');
	}
	
	function index() {
		$pagedata = array();

		$projects = array();

		$query = $this->db->query('SELECT id,name FROM kanban_project');
		$i=0;
		foreach ($query->result_array() as $row)
		{
			$projects[$i]=$row;
			$i++;
		}
		$pagedata['projects'] = $projects;	
		$this->load->view('kanban/selectproject', $pagedata);
	}
	function settings($projectid) {

		$pagedata['projectid'] = $projectid;

		$projectname = "no-name";
		$query = $this->db->query('SELECT id,name FROM kanban_project WHERE id = '.$projectid);
		if ($query->num_rows() > 0)	{
			$res = $query->result_array();		
			// print_r( $release );		
			$projectname = $res[0]['name'];	
		} 
		$pagedata['projectname'] = $projectname;

		$groups = array();
		$query = $this->db->query('SELECT id,name FROM kanban_group WHERE project_id = '.$projectid);
		$i=0;
		foreach ($query->result_array() as $row)
		{
			$groups[$i]=$row;
			$i++;
		}

		$pagedata['groups'] = $groups;

		$tasks = array();
		$query = $this->db->query('SELECT k.id as taskid,heading,group_id,name as groupname,priority FROM kanban_item k,kanban_group g WHERE group_id = g.id AND k.project_id = '.$projectid.' ORDER BY group_id');
		$i=0;
		foreach ($query->result_array() as $row)
		{
			$tasks[$i]=$row;
			$i++;
		}

		$pagedata['tasks'] = $tasks;

		$this->load->view('kanban/settings', $pagedata);
	}

	function project($projectid)    {
		$pagedata = array();
		$pagedata['projectid'] = $projectid;
		$projectname = "no-name";
		$query = $this->db->query('SELECT id,name FROM kanban_project WHERE id = '.$projectid);
		if ($query->num_rows() > 0)	{
			$res = $query->result_array();		
			// print_r( $release );		
			$projectname = $res[0]['name'];	
		} 
		$pagedata['projectname'] = $projectname;	

		$groups = array();

		$sql='SELECT id,name FROM kanban_group WHERE project_id = '.$projectid.' ORDER BY displayorder';
		$query = $this->db->query($sql);
		$i=0;
		foreach ($query->result_array() as $row)
		{
			$groups[$i]=$row;			
			$i++;
		}
		$pagedata['groups'] = $groups;

		$tasks = array();
		$query = $this->db->query('SELECT k.id as taskid,heading,group_id,name as groupname,priority FROM kanban_item k,kanban_group g WHERE group_id = g.id AND k.project_id = '.$projectid.' ORDER BY displayorder');
		$i=0;
		foreach ($query->result_array() as $row)
		{
			$tasks[$i]=$row;
			$i++;
		}

		$pagedata['tasks'] = $tasks;

		$this->load->view('kanban/board', $pagedata);
	}

	function opera()    {
		$data = array();
		$this->load->view('kanban/opera', $data);
	}

	function taskdetails($projectid,$taskid) {
//		$projectid = $this->input->post('projectid');
//		$taskid = $this->input->post('taskid');
		$sql = 'SELECT heading,priority,description,estimation FROM kanban_item WHERE project_id = '.$projectid.' AND id = '.$taskid;
		$query = $this->db->query( $sql );
		$jsonarray = array();
		if ($query->num_rows() > 0)	{
			$row = $query->row();	
			$jsonarray[ 'heading' ] = $row->heading;
			$jsonarray[ 'taskdescription' ] = $row->description;
			$jsonarray[ 'priority' ] = $row->priority;
			$jsonarray[ 'estimation' ] = $row->estimation;	
			$jsonarray[ 'projectid' ] = $projectid;		
			$jsonarray[ 'taskid' ] = $taskid;			
		} 
		$jsondata = json_encode($jsonarray);
		echo $jsondata; 
	}

	function add() {
		$group = $this->input->post('group');
		$heading = $this->input->post('heading');
		$priority = $this->input->post('priority');
		$taskdescription = $this->input->post('taskdescription');
		$estimation = $this->input->post('estimation');
		echo "group=".$group."<br>";
		echo "head=".$heading."<br>";
		echo "prio=".$priority."<br>";	
		echo "desc=".$taskdescription."<br>";
		echo "desc=".$estimation."<br>";
		$data = array(
			'group_id' => $group,
			'heading' => $heading,
			'priority' => $priority,
			'description' => $taskdescription,
			'estimation' => $estimation
			);
		$this->db->insert('kanban_item', $data);	
		$query = $this->db->query('SELECT max(id) as lastid FROM kanban_item');
		$taskid = 0;
		if ($query->num_rows() > 0)	{
			$res = $query->result_array();		
			// print_r( $release );		
			$taskid = $res[0]['lastid'];	
		} 
 		echo "task-id=".$taskid."<br>";	
		echo "inserted into db!";
	}


	function move() {
		$from = $this->input->post('from');
		$to = $this->input->post('to');
		$task = $this->input->post('task');
		echo "from=".$from."<br>";
		echo "to=".$to."<br>";
		echo "task=".$task."<br>";	
		$data = array(
			'group_id' => $to
			);
		$this->db->where('id', $task);
		$this->db->update('kanban_item', $data);
		echo "moved in db!";
	}

	function addgroup() {
		$name = $this->input->post('name');
		echo "name=".$name."<br>";
		$projectid = $this->input->post('projectid');
		echo "projectid=".$projectid."<br>";
		$data = array(
			'name' => $name,
			'project_id' => $projectid
			);
		$this->db->insert('kanban_group', $data);	
		$query = $this->db->query('SELECT max(id) as lastid FROM kanban_group');
		$groupid = 0;
		if ($query->num_rows() > 0)	{
			$res = $query->result_array();		
			// print_r( $release );		
			$groupid = $res[0]['lastid'];	
		} 
 		echo "group-id=".$groupid."<br>";	
		echo "inserted into db!";
	}

	function changegrouporder() {
		$grouporder = rtrim( $this->input->post('grouporder'), ',');
		echo "grouporder=".$grouporder."<br>";
		$projectid = $this->input->post('projectid');
		echo "projectid=".$projectid."<br>";
		$listofgroups = explode( ",", $grouporder );
		$index = 1;
		foreach( $listofgroups as $groupid ) {
			$data = array(
				'displayorder' => $index
				);
			$this->db->where('id', $groupid);
			$this->db->update('kanban_group', $data);	
			$index++;
		}
 
	}


	function addproject() {
		$name = $this->input->post('name');
		// echo "name=".$name."<br>";
		$data = array(
			'name' => $name
			);
		$this->db->insert('kanban_project', $data);	
		$query = $this->db->query('SELECT max(id) as lastid FROM kanban_project');
		$projectid = 0;
		if ($query->num_rows() > 0)	{
			$res = $query->result_array();		
			// print_r( $release );		
			$projectid = $res[0]['lastid'];	
		} 
 		//echo "project-id=".$projectid."<br>";	
		//echo "inserted into db!";
		kanban::project( $projectid );
	}



	function jsonStep1() {
		$res = array();
		$res["php_message"] = "I am PHP";
		echo json_encode($res);
	}

	function json() {
		$data = array();
		$this->load->view('kanban/json', $data);
	}


	function tabs() {
		$data = array();
		$this->load->view('kanban/tabs', $data);
	}

	function get() {
		//$res = json_decode($_REQUEST['data'], true);
		$res=array();
		$res["php_message"] = "I am PHP";
		echo json_encode($res);
	}
}

?>
