<?php

class sdp extends Controller {

	function sdp()
	{
		parent::Controller();
		$this->load->database();
		$this->load->library('session');
		$this->load->plugin('js_calendar');
		$this->load->helper('form');
		$this->load->helper('url');
	}

	function index()
	{
		$this->load->library('table');
		$pagedata = array();
		$releases = array();

		$query = $this->db->query('SELECT r.id,header,deliverydate,modified_timestamp,s.name as status_name FROM sdp_release r, sdp_release_status s WHERE status_id IN ( 1,2,3,4,5,8 ) AND r.status_id = s.id ORDER BY header');
		$i=0;
		foreach ($query->result_array() as $row)
		{
			$releases[$i] = $row;
			$i++;
		}

		$pagedata['releases'] =  $releases;

		$this->load->view('sdp_header');
		$this->load->view('sdp_home', $pagedata);
		$this->load->view('sdp_footer');
	}

	function admin() {
		$this->load->view('sdp_header');
		$this->load->view('sdp_admin');
		$this->load->view('sdp_footer');
        }


        function lostpassword() {
                $query = $this->db->query('SELECT username,email,team FROM sdp_user order by email');
		$i=0;
		foreach ($query->result_array() as $row)
		{
			$users[$i] = $row;
			$i++;
		}

		$pagedata['users'] =  $users;
		$this->load->view('sdp_header');
		$this->load->view('sdp_lostpassword',$pagedata);
		$this->load->view('sdp_footer');
        }

	function logout() {
		$this->session->sess_destroy();
                sdp::index();
	}
	
	function login($redirect_to_url='')
	{
		$pagedata['errormessage'] = '';
		$pagedata['redirect_to_url'] = $redirect_to_url;
                if( strlen( trim( $redirect_to_url ) ) <= 0 ) {
                    $redirect_to_url = "/sdp";
                    $pagedata['redirect_to_url'] = $redirect_to_url;
                }
                if( strlen( trim( $this->input->post('redirect_to_url') ) ) > 0 ) {
                  $pagedata['redirect_to_url'] = $this->input->post('redirect_to_url');
                  $redirect_to_url = $this->input->post('redirect_to_url');
                }

		// check to see if we are loging in or if we are viewing the login page
		if( $this->input->post('username') == FALSE ) {
			$this->load->view('sdp_header');
			$this->load->view('sdp_login',$pagedata);
			$this->load->view('sdp_footer');
			return;
		}
                 // echo "#url=".$redirect_to_url."<br>";
                 // return;

		// verify username and password in the database
		$md5password = md5( $this->input->post('password') );
		$query = $this->db->query("SELECT username FROM sdp_user WHERE password = '".$md5password."' AND username = '".$this->input->post('username')."'");
		if ($query->num_rows() <= 0)
		{
			// Oops! no such user
			$pagedata['errormessage'] = 'Sorry wrong username or password!';
			$this->load->view('sdp_header');
			$this->load->view('sdp_login',$pagedata);
			$this->load->view('sdp_footer');
			return;
		}
		// Set session / login OK
		$this->session->set_userdata('username', $this->input->post('username'));
		$this->session->set_userdata('logged_in', 'TRUE');

		header("Location: ".$redirect_to_url );
	}
        
        function login2()
	{
		$pagedata['errormessage'] = '';


		// check to see if we are loging in or if we are viewing the login page		
		if( $this->input->post('username') == FALSE ) {
			$this->load->view('sdp_header');
			$this->load->view('sdp_login',$pagedata);
			$this->load->view('sdp_footer');
			return;
		}
		// verify username and password in the database		
		$md5password = md5( $this->input->post('password') );
		$query = $this->db->query("SELECT username FROM sdp_user WHERE password = '".$md5password."' AND username = '".$this->input->post('username')."'");
		if ($query->num_rows() <= 0)
		{
			// Oops! no such user
			$pagedata['errormessage'] = 'Sorry wrong username or password!';
			$this->load->view('sdp_header');
			$this->load->view('sdp_login', $pagedata);
			$this->load->view('sdp_footer');
			return;
		}		
		// Set session / login OK
		$this->session->set_userdata('username', $this->input->post('username'));
		$this->session->set_userdata('logged_in', 'TRUE');
		
		sdp::index();
	}

        function updateuserprofile($username,$resetpasswordcode) {
      		$query = $this->db->query("SELECT username FROM sdp_user WHERE resetpasswordcode = '".$resetpasswordcode."' AND username = '".$username."'");
    		if ($query->num_rows() <= 0)
	        {
             		// Oops! no such user
    			$pagedata['errormessage'] = 'Invalid password reset !!!';
    			$this->load->view('sdp_header');
    			$this->load->view('sdp_login',$pagedata);
    			$this->load->view('sdp_footer');
      			return;
            	}
                register($username,$resetpasswordcode);
        }

	function register($username="",$resetpasswordcode="")
	{
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		$pagedata['errormessage'] = '';
		
		if( strlen( $username ) > 0 ) {

                }


                $teamarray = array();
		$query = $this->db->query("SELECT DISTINCT team FROM sdp_user ORDER BY team");
		$i=0;
		foreach ($query->result_array() as $row)
		{
         		$teamarray[$i]=$row['team'];         		
         		$i++;
		}
		$pagedata['teamarray'] = $teamarray;

		$this->load->view('sdp_header');

		$this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[5]|max_length[12]|xss_clean');
		$this->form_validation->set_rules('team', 'Team', 'trim|required|min_length[5]|max_length[20]|xss_clean');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|matches[password2]|md5');
		$this->form_validation->set_rules('password2', 'Password Confirmation', 'trim|required');
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');						

		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('sdp_register', $pagedata );
		}
		else
		{
			// See if we can find a user which has email or username allready
			$query = $this->db->query("SELECT username FROM sdp_user WHERE email = '".$this->input->post('email')."' ");						
			if ($query->num_rows() > 0)
			{
				// Oops! allready a user, can not re-register!!!
				$pagedata['errormessage'] = 'You can not re-register, email adress ('.$this->input->post('email').') allready registred.';
				$this->load->view('sdp_register', $pagedata );
				$this->load->view('sdp_footer');
				return;
			}

			$query = $this->db->query("SELECT username FROM sdp_user WHERE username = '".$this->input->post('username')."' ");			
			if ($query->num_rows() > 0)
			{
				// Oops! allready a user, can not re-register!!!
				$pagedata['errormessage'] = 'You can not re-register, username ('.$this->input->post('username').') allready registred.';
				$this->load->view('sdp_register', $pagedata );
				$this->load->view('sdp_footer');
				return;
			}
			
			// Store in DB
			$data = array(
					   'username' => $this->input->post('username'),
					   'team' => $this->input->post('team'),
					   'email' => $this->input->post('email'),
					   'password' => $this->input->post('password')
					);			
			$this->db->insert('sdp_user', $data); 
			if( $this->db->affected_rows() <= 0 ) {
				// Oops! seems we can not add the user to the db
				$pagedata['errormessage'] = 'Oops! unable to register due to database error... ';
				$this->load->view('sdp_register', $pagedata );
				$this->load->view('sdp_footer');
				return;					
			}

			//
			// S�tt Session-Cookie
			//
			$this->session->set_userdata('username', $this->input->post('username'));
			$this->session->set_userdata('team', $this->input->post('team'));
			$this->session->set_userdata('logged_in', 'TRUE');

			sdp::index();
		}

		$this->load->view('sdp_footer');
	
	}

	function editrelease($release_id) {
		sdp::modifyrelease( $release_id );
	}
	
	function addrelease() {
		sdp::modifyrelease( 0 );
	}

	function modifyrelease($release_id)
	{
		if ($this->session->userdata('logged_in') != TRUE) {
			sdp::login( uri_string() );
			return;
	        }
		
		$pagedata['formname'] = 'addrelease';
		
		// if the post return FALSE we know this is a request to ADD a new Release

		if( $this->input->post('submit') == FALSE ) {
			if( $release_id <= 0 ) {
				// Lets fill in the some default data
				$pagedata['id'] = 0;
				$pagedata['header'] = 'CS x.0 CPy ICPzz';
				$pagedata['branch'] = 'branch-name';
				$pagedata['comment'] = '';
				$pagedata['status'] = 0; // Not Started
				$pagedata['contentfreeze'] = date( "Y-m-d", time());
				$pagedata['codefreeze'] = date( "Y-m-d", time());
				$pagedata['deliverydate'] = date( "Y-m-d", time());
				$pagedata['lsvdeliverydate'] = date( "Y-m-d", time());
				$pagedata['contentfreeze_time'] = time();
				$pagedata['codefreeze_time'] = time();
				$pagedata['deliverydate_time'] = time();
				$pagedata['lsvdeliverydate_time'] = time();
				$pagedata['child_releases'] = array();
			} else {
				// so we are looking at an existing release, lets fetch it from the db
				$query = $this->db->query('SELECT id,header,branch,comment,status_id,contentfreeze,codefreeze,deliverydate,lsvdeliverydate FROM sdp_release WHERE id = '.$release_id);
				if ($query->num_rows() > 0)	{
					$release = $query->result_array();		
					// print_r( $release );		
					$pagedata['id'] = $release[0]['id'];
					$pagedata['header'] = $release[0]['header'];
					$pagedata['branch'] = $release[0]['branch'];
					$pagedata['comment'] = $release[0]['comment'];
					$pagedata['status'] = $release[0]['status_id']; // Not Started
					$pagedata['contentfreeze'] = $release[0]['contentfreeze'];
					$pagedata['codefreeze'] = $release[0]['codefreeze'];
					$pagedata['deliverydate'] = $release[0]['deliverydate'];				
					$pagedata['lsvdeliverydate'] = $release[0]['lsvdeliverydate'];										
					$date_array = preg_split( "/[-\s]/", $release[0]['contentfreeze'] );					
					$pagedata['contentfreeze_time'] = mktime(0,0,0,$date_array[1],$date_array[2],$date_array[0]);
					$date_array = preg_split( "/[-\s]/", $release[0]['codefreeze'] );
					$pagedata['codefreeze_time'] = mktime(0,0,0,$date_array[1],$date_array[2],$date_array[0]);
					$date_array = preg_split( "/[-\s]/", $release[0]['deliverydate'] );
					$pagedata['deliverydate_time'] = mktime(0,0,0,$date_array[1],$date_array[2],$date_array[0]);
					$date_array = preg_split( "/[-\s]/", $release[0]['lsvdeliverydate'] );
					$pagedata['lsvdeliverydate_time'] = mktime(0,0,0,$date_array[1],$date_array[2],$date_array[0]);
				}
			}
			//
			// possible release/package states
			$statusarray = array();
			$query = $this->db->query('SELECT id, name FROM sdp_release_status');

			foreach ($query->result_array() as $row)
			{
				$statusarray[$row['id']]=$row['name'];
			}

			$pagedata['statusarray'] = $statusarray;
			$child_releases = array();
			$query = $this->db->query('SELECT s.child_release_id as id, r.header, r.branch,r.codefreeze FROM sdp_complementary_release s, sdp_release as r WHERE s.parent_release_id = '.$release_id.' AND r.id = s.child_release_id ORDER BY r.header' );
			$i=0;
			foreach ($query->result_array() as $row)
			{
				$child_releases[$i] = $row;	
				$i++;
			}
			$pagedata['child_releases'] =  $child_releases;
			
			$this->load->view('sdp_header',$pagedata);
			$this->load->view('sdp_add_release');
			$this->load->view('sdp_footer');						
		} else {
			if( $this->input->post('id') == 0 ) {
				// id = 0, indicates that we are adding a new release
				$data = array(
					'header' => $this->input->post('header'),
					'branch' => $this->input->post('branch'),
					'status_id' => $this->input->post('status'),
					'contentfreeze' => $this->input->post('contentfreeze'),
					'codefreeze' => $this->input->post('codefreeze'),
					'deliverydate' => $this->input->post('deliverydate'),
					'lsvdeliverydate' => $this->input->post('lsvdeliverydate'),
					'modified_by' => $this->session->userdata('username'),
					'comment' => $this->input->post('comment'),
					'modified_timestamp' => date( "Y-m-d H:i:s", time() )
					);
				$this->db->insert('sdp_release', $data); 
				$query = $this->db->query('SELECT max(id) as id FROM sdp_release ORDER BY id DESC LIMIT 1');
				if ($query->num_rows() > 0)	{
					$release = $query->result_array();		
					$release_id = $release[0]['id'];
				}
			} else {
				// id != 0 means that we are modifying an existing release
				// what was the old values
				$query = $this->db->query('SELECT id,header,branch,comment,status_id,contentfreeze,codefreeze,deliverydate,lsvdeliverydate FROM sdp_release WHERE id = '.$release_id);
				$release = $query->result_array();		
				// print_r( $release );		
				$old = array();
				$old['id'] = $release[0]['id'];
				$old['header'] = $release[0]['header'];
				$old['branch'] = $release[0]['branch'];
				$old['comment'] = $release[0]['comment'];
				$old['status'] = $release[0]['status_id'];; // Not Started
				$old['contentfreeze'] = $release[0]['contentfreeze'];
				$old['codefreeze'] = $release[0]['codefreeze'];
				$old['deliverydate'] = $release[0]['deliverydate'];
				$old['lsvdeliverydate'] = $release[0]['lsvdeliverydate'];

				$data = array(
					'header' => $this->input->post('header'),
					'branch' => $this->input->post('branch'),
					'status_id' => $this->input->post('status'),
					'contentfreeze' => $this->input->post('contentfreeze'),
					'codefreeze' => $this->input->post('codefreeze'),
					'deliverydate' => $this->input->post('deliverydate'),
					'lsvdeliverydate' => $this->input->post('lsvdeliverydate'),
					'modified_by' => $this->session->userdata('username'),
					'comment' => $this->input->post('comment'),
					'modified_timestamp' => date( "Y-m-d H:i:s", time() )
					);

				$this->db->where('id', $this->input->post('id'));
				$this->db->update('sdp_release', $data);

				$message="Modified release, changed the following; ";
				if( strcmp( $old['status'], $this->input->post('status') ) != 0 ) {
                                        $query = $this->db->query('SELECT id,name FROM sdp_release_status WHERE id IN ('.$old['status'].','.$this->input->post('status').')' );
                                        $result = $query->result_array();
                                        if( $result[0]['id'] == $old['status'] ) {
                                            $oldstatus = $result[0]['name'];
                                            $newstatus = $result[1]['name'];
                                        } else {
                                            $oldstatus = $result[1]['name'];
                                            $newstatus = $result[0]['name'];
                                        }
					$message=$message."<br>Status from \"".$oldstatus."\" to \"".$newstatus."\"\n";
				}
                                if( strcmp( $old['header'], $this->input->post('header') ) != 0 ) {
					$message=$message."<br>Header from ".$old['header']." to ".$this->input->post('header')."\n";
				}
				if( strcmp( $old['branch'], $this->input->post('branch') ) != 0 ) {
					$message=$message."<br>Branch from ".$old['branch']." to ".$this->input->post('branch')."\n";
				}
				if( strcmp( $old['comment'], $this->input->post('comment') ) != 0 ) {
					$message=$message."<br>Comment from<br>\"".$old['comment']."\"<br>to<br>\"".$this->input->post('comment')."\"<br>\n";
				}
				if( strcmp( $old['contentfreeze'], $this->input->post('contentfreeze') ) != 0 ) {
					$message=$message."<br>Contentfreeze from ".$old['contentfreeze']." to ".$this->input->post('contentfreeze')."\n";
				}
				if( strcmp( $old['codefreeze'], $this->input->post('codefreeze') ) != 0 ) {
					$message=$message."<br>Codefreeze from ".$old['codefreeze']." to ".$this->input->post('codefreeze')."\n";
				}
				if( strcmp( $old['deliverydate'], $this->input->post('deliverydate') ) != 0 ) {
					$message=$message."<br>Delivery date from ".$old['deliverydate']." to ".$this->input->post('deliverydate')."\n";
				}
				if( strcmp( $old['lsvdeliverydate'], $this->input->post('lsvdeliverydate') ) != 0 ) {
					$message=$message."<br>LSV delivery date from ".$old['lsvdeliverydate']." to ".$this->input->post('lsvdeliverydate')."\n";
				}
				
				$data = array(
					'release_id' => $this->input->post('id'),
					'submitted_by' => $this->session->userdata('username'),
					'submitted' => date( "Y-m-d H:i:s", time() ),
					'message' => $message
				);
				$this->db->insert('sdp_comment', $data);
			}

			header("Location: "."/sdp/viewrelease/".$release_id);
		}
		
	}
	
	
	function viewreleases()
	{
		$this->load->library('table');
		$pagedata = array();
		$releases = array();

		$query = $this->db->query('SELECT r.id,header,deliverydate,modified_timestamp,s.name as status_name FROM sdp_release r, sdp_release_status s WHERE r.status_id = s.id ORDER BY header');	
		$i=0;
		foreach ($query->result_array() as $row)
		{
			$releases[$i] = $row;
			$i++;
		}

		$pagedata['releases'] =  $releases;

		$this->load->view('sdp_header');
		$this->load->view('sdp_view_releases', $pagedata);
		$this->load->view('sdp_footer');
	}

	function viewreleaseswithfullinformation()
	{
		$this->load->library('table');
		$pagedata = array();
		$releases = array();

		$query = $this->db->query('SELECT r.id,header,deliverydate,contentfreeze,codefreeze,lsvdeliverydate,modified_timestamp,s.name as status_name FROM sdp_release r, sdp_release_status s WHERE r.status_id = s.id ORDER BY header');
		$i=0;
		foreach ($query->result_array() as $row)
		{
			$releases[$i] = $row;
			$i++;
		}

		$pagedata['releases'] =  $releases;

		$this->load->view('sdp_header');
		$this->load->view('sdp_view_releases_with_full_information', $pagedata);
		$this->load->view('sdp_footer');
	}

	function viewrelease( $release_id, $tr_sort_order = 0 ) {
		$this->load->helper('text');
		$pagedata = array();
		$pagedata['formname'] = 'viewrelease';
		$pagedata['id'] =  $release_id;
		$query = $this->db->query('SELECT rel.id as release_id,header,branch,comment,status_id,contentfreeze,codefreeze,lsvdeliverydate,deliverydate, rel_stat.name as release_status, modified_by, modified_timestamp FROM sdp_release rel, sdp_release_status rel_stat WHERE rel.id = '.$release_id.' AND rel.status_id = rel_stat.id');
		$row = $query->row_array();
		$pagedata['id'] = $row['release_id'];
		$pagedata['header'] = $row['header'];
		$pagedata['branch'] = $row['branch'];
		$pagedata['comment'] = $row['comment'];
		$pagedata['status'] = $row['status_id'];; // Not Started
		$pagedata['contentfreeze'] = $row['contentfreeze'];
		$pagedata['codefreeze'] = $row['codefreeze'];
		$pagedata['deliverydate'] = $row['deliverydate'];					
		$pagedata['lsvdeliverydate'] = $row['lsvdeliverydate'];										
		$date_array = preg_split( "/[-\s]/", $row['contentfreeze'] );
		// print_r( $date_array );
		$pagedata['contentfreeze_time'] = mktime(0,0,0,$date_array[1],$date_array[2],$date_array[0]);
		$date_array = preg_split( "/[-\s]/", $row['codefreeze'] );
		$pagedata['codefreeze_time'] = mktime(0,0,0,$date_array[1],$date_array[2],$date_array[0]);
		$date_array = preg_split( "/[-\s]/", $row['deliverydate'] );
		$pagedata['deliverydate_time'] = mktime(0,0,0,$date_array[1],$date_array[2],$date_array[0]);
		$date_array = preg_split( "/[-\s]/", $row['lsvdeliverydate'] );
		$pagedata['lsvdeliverydate_time'] = mktime(0,0,0,$date_array[1],$date_array[2],$date_array[0]);
		$pagedata['release_status'] = $row['release_status'];
		$pagedata['modified_by'] = $row['modified_by'];
		$pagedata['modified_timestamp'] = $row['modified_timestamp'];
		
		##
		## List Child Releases
		##
		$child_releases = array();
		$query = $this->db->query('SELECT s.child_release_id as id, r.header, r.branch,r.codefreeze FROM sdp_complementary_release s, sdp_release as r WHERE s.parent_release_id = '.$release_id.' AND r.id = s.child_release_id ORDER BY r.header' );
		$i=0;
		$listofchildreleases="";
		foreach ($query->result_array() as $row)
		{
			$child_releases[$i] = $row;
			$listofchildreleases=$listofchildreleases.$row['id'].",";
			$i++;
		}
		$pagedata['child_releases'] =  $child_releases;
		$listofchildreleases = rtrim( $listofchildreleases, "," );

		$trs = array();
		switch( $tr_sort_order ) {
			case 0:		
				$tr_sort_order_string = 'tr.tr_number';
				break;
			case 1:		
				$tr_sort_order_string = 'tr.submitted';
				break;
			case 2:		
				$tr_sort_order_string = 'tr.tag';
				break;
			case 3:
				$tr_sort_order_string = 'trs.status';
				break;
			case 4:
				$tr_sort_order_string = 'trs.prio';
				break;
			case 5:
				$tr_sort_order_string = 'tr.confirmed_ok';
				break;
			case 6:
				$tr_sort_order_string = 'trs.registred';
				break;
			case 7:
				$tr_sort_order_string = 'trs.answer';
				break;
			default:
				$tr_sort_order_string = 'tr.tr_number';
				break;
		}			

		##
		## List TRs
		##
		$sql = 'SELECT id,tr.tr_number,submitted_by,submitted,confirmed_ok,tag,deleted,comment,trs.title as title, trs.prio as prio, trs.status as status, trs.answer as answer, trs.registred as registred FROM sdp_tr tr, sdp_tr_status trs WHERE tr.deleted = 0 AND trs.tr_number = tr.tr_number AND tr.release_id ='.$release_id.' ORDER BY '.$tr_sort_order_string;
		$query = $this->db->query( $sql );	
		$i=0;
		foreach ($query->result_array() as $row)
		{
			$trs[$i] = $row;
			$i++;
		}
		$pagedata['trs'] =  $trs;
		
		##
		## List TRs of Child-releases
		##
		$child_trs = array();
		if( strlen( trim( $listofchildreleases ) ) > 0 ) {
			$sql = 'SELECT tr.release_id,r.header,tr.id, tr.tr_number,submitted_by,submitted,confirmed_ok,tag,deleted,tr.comment,trs.title as title, trs.prio as prio, trs.status as status, trs.answer as answer, trs.registred as registred FROM sdp_tr tr, sdp_tr_status trs, sdp_release r WHERE tr.deleted = 0 AND trs.tr_number = tr.tr_number AND tr.release_id = r.id AND tr.release_id in ('.$listofchildreleases.') order by r.header,tr_number';
			$query = $this->db->query( $sql );	
			$i=0;
			foreach ($query->result_array() as $row)
			{
				$child_trs[$i] = $row;
				$i++;
			}
		}
		$pagedata['child_trs'] =  $child_trs;

		##
		## List Docs
		##
		$docs = array();
		$query = $this->db->query('SELECT id,doc_number,doc_revision,submitted_by,submitted,comment FROM sdp_document WHERE release_id = '.$release_id.' ORDER BY doc_number' );
		$i=0;
		foreach ($query->result_array() as $row)
		{
			$docs[$i] = $row;
			$i++;
		}
		$pagedata['docs'] =  $docs;

		##
		## List Docs from Child-Releases
		##
		$childdocs = array();
		if( strlen( trim( $listofchildreleases ) ) > 0 ) {
			$query = $this->db->query('SELECT d.release_id, r.header, d.id,doc_number,doc_revision,submitted_by,submitted,d.comment FROM sdp_document d,sdp_release r WHERE release_id IN ('.$listofchildreleases.') AND r.id = d.release_id ORDER BY r.header,doc_number' );
			$i=0;
			foreach ($query->result_array() as $row)
			{
				$childdocs[$i] = $row;
				$i++;
			}
		}
		$pagedata['childdocs'] =  $childdocs;


		##
		## List PCs
		##
		$pcs = array();
		$query = $this->db->query('SELECT id,pc_number,link,comment,submitted_by,submitted FROM sdp_pc WHERE release_id = '.$release_id.' ORDER BY pc_number' );
		$i=0;
		foreach ($query->result_array() as $row)
		{
			$pcs[$i] = $row;
			$i++;
		}
		$pagedata['pcs'] =  $pcs;


		##
		## List CRs
		##
                $crs = array();
		$query = $this->db->query('SELECT id,cr_number,link,comment,submitted_by,submitted FROM sdp_cr WHERE release_id = '.$release_id.' ORDER BY cr_number' );
		$i=0;
		foreach ($query->result_array() as $row)
		{
			$crs[$i] = $row;
			$i++;
		}
		$pagedata['crs'] =  $crs;

		##
		## List History
		##
		$history = array();
		$query = $this->db->query('SELECT submitted_by,submitted,message FROM sdp_comment where release_id ='.$release_id.' ORDER BY submitted DESC' );	
		$i=0;
		foreach ($query->result_array() as $row)
		{
			$history[$i] = $row;
			$i++;
		} 
		$pagedata['history'] =  $history;
		
		$this->load->view('sdp_header', $pagedata); 
		$this->load->view('sdp_view_release', $pagedata);
		$this->load->view('sdp_footer');	
	}

	function addtrs($release_id) {
		$pagedata = array();
		$pagedata['formname'] = 'addtrs';
		$pagedata['id'] =  $release_id;
		$pagedata['errortext'] = '';
		$pagedata['trlist'] = '';
		$pagedata['tag'] = '';
		$pagedata['header'] = '';
		$errortext = "";
	
		if ($this->session->userdata('logged_in') != TRUE) {
			sdp::login( uri_string() );
			return;
	    }

		
		if( $this->input->post('submit') == FALSE ) {
			$query = $this->db->query('SELECT id,header FROM sdp_release WHERE id = '.$release_id);
			if ($query->num_rows() > 0)	{
					$release = $query->result_array();		
					// print_r( $release );		
					$pagedata['id'] = $release[0]['id'];
					$pagedata['header'] = $release[0]['header'];
			} else {
				// Failed
				echo "Failed to get release from db!";
			}			
			$this->load->view('sdp_header', $pagedata); 
			$this->load->view('sdp_add_trs', $pagedata); 
			$this->load->view('sdp_footer');				
			return;
		} else {
			$trsWeAllreadyHave = array();
			$query = $this->db->query('SELECT tr_number FROM sdp_tr where release_id ='.$release_id.' ORDER BY tr_number' );	
			$i=0;
			foreach ($query->result_array() as $row)
			{
				$trsWeAllreadyHave[$i] = $row['tr_number'];
				$i++;
			}
			$trlist_string =  $this->input->post('trlist');
			$trlist = preg_split('/[\\n\\r]/', $trlist_string,-1,PREG_SPLIT_NO_EMPTY);
			$errortext = "";
			$trlist_string = "";
			$listOfTRsAsString = "";
			foreach ($trlist as $tr) { 
				$tr = trim( strtoupper( $tr ) );
				if( preg_match( "/^[a-z][a-z][0-9][0-9][0-9][0-9][0-9]$/i",$tr ) ) {
					## The TR matched the TR-format HK89123
					## Lets make sure we have not allready added it
					if( in_array($tr,$trsWeAllreadyHave) == FALSE ) {
						$data = array(
							'release_id' => $this->input->post('id'),
							'tag' => $this->input->post('tag'),
							'tr_number' => $tr,
							'submitted_by' => $this->session->userdata('username'),
							'submitted' => date( "Y-m-d H:i:s", time() ),
							'confirmed_ok' => 0,
							'deleted' => 0,
						);
						$this->db->insert('sdp_tr', $data); 					
						
						## Insert the TR in the sdp_tr_status table, so that we can get status info about it
						$sql = "INSERT IGNORE INTO sdp_tr_status (tr_number, title, prio, status, answer, registred, updated ) values ( '".$tr."','- TR needs to be updated -', 'N/A', 'N/A', 'N/A', '1970-01-01', '".date( "Y-m-d H:i:s", time() )."' )";
						$query = $this->db->query( $sql );
						
						$listOfTRsAsString = $listOfTRsAsString.",".$tr;
					}
				}
				else {
					## Failed to interpret TR
					$errortext = $errortext.$tr."<br>";
					$trlist_string = $trlist_string."$tr\n";
				}							
			}
			$message="Added the following TRs (".$listOfTRsAsString.")";
				$data = array(
					'release_id' => $this->input->post('id'),
					'submitted_by' => $this->session->userdata('username'),
					'submitted' => date( "Y-m-d H:i:s", time() ),
					'message' => $message
				);
			$this->db->insert('sdp_comment', $data);
                        sdp::markReleaseAsModified( $this->input->post('id') );

			if( strlen( trim( $errortext ) ) > 0 ) {
				## Apparently there were a few faults in the input
				$errortext = "Failed to interpret the following TRs!<br>".$errortext;
				$pagedata['errortext'] = $errortext;
				$pagedata['tag'] = $this->input->post('tag');
				$pagedata['trlist'] = $trlist_string;
				$pagedata['header'] = $this->input->post('header');
				$this->load->view('sdp_header', $pagedata); 
				$this->load->view('sdp_add_trs', $pagedata); 
				$this->load->view('sdp_footer');				
			} else {
				## Sucess TRs added to the release
				header("Location: "."/sdp/viewrelease/".$release_id);
			}
		}
	
	}
	
	function markReleaseAsModified( $release_id ) {
                $data = array(
        	       'modified_timestamp' => date( "Y-m-d H:i:s", time() )
		);
	        $this->db->where('id', $release_id );
                $this->db->update('sdp_release', $data);
        }

	function confirmtrs($release_id) {
		$pagedata = array();
		$pagedata['formname'] = '';
		$pagedata['id'] =  $release_id;
		$pagedata['errortext'] = '';
		$pagedata['trlist'] = '';
		$pagedata['tag'] = '';
		$pagedata['header'] = '';
		$errortext = "";
		
		if ($this->session->userdata('logged_in') != TRUE) {
			sdp::login( uri_string() );
			return;
	    }
	
		if( $this->input->post('submit') == FALSE ) {
			$query = $this->db->query('SELECT id,header FROM sdp_release WHERE id = '.$release_id);
			if ($query->num_rows() > 0)	{
					$release = $query->result_array();		
					$pagedata['header'] = $release[0]['header'];
			}
			## List all TRs for this release
			$trs = array();
			$query = $this->db->query('SELECT id,tr_number,submitted_by,confirmed_ok FROM sdp_tr where release_id ='.$release_id.' ORDER BY tr_number' );	
			$i=0;
			foreach ($query->result_array() as $row)
			{
				$trs[$i] = $row;
				$i++;
			}
			$pagedata['trs'] =  $trs;
			
			$this->load->view('sdp_header', $pagedata); 
			$this->load->view('sdp_confirm_trs', $pagedata); 
			$this->load->view('sdp_footer');			
			return;
		} else {
			## act on change in the tr-list, i.e. confirm or unconfirm TRs
			$sql_in_statement = "";
			$confirmedHash = array();
			$confirmed = $this->input->post('confirmed');
			$count=count($confirmed);
			for($i=0;$i<$count;$i++){ 
				$confirmedHash[ $confirmed[$i] ] = 1;				
			}

			$list_of_confirmed = "";
			$list_of_unconfirmed = "";
			$query = $this->db->query('SELECT id,confirmed_ok FROM sdp_tr where release_id ='.$release_id.' ORDER BY id' );	
			$i=0;
			foreach ($query->result_array() as $row)
			{
				if( array_key_exists( $row['id'], $confirmedHash ) ) {
					if( $row['confirmed_ok'] <= 0 ) {
						// This means that the TR was previously NOT set and thus has just been set to CONFIRMED
						if( strlen( trim( $list_of_confirmed ) ) <= 0 ) {
							$list_of_confirmed = $row['id'];
						} else {
							$list_of_confirmed = $list_of_confirmed.",".$row['id'];
						}
					}
				} else {
					if( $row['confirmed_ok'] > 0 ) {
						// This means that BEFORE it was set to CONFIRMED and NOW it is not, lets UNCOFIRM it
						if( strlen( trim( $list_of_unconfirmed ) ) <= 0 ) {
							$list_of_unconfirmed = $row['id'];
						} else {
							$list_of_unconfirmed = $list_of_unconfirmed.",".$row['id'];
						}
					}
				}
				$i++;
			}
#			echo "confirmed: --".$list_of_confirmed."--<br>\n";
#			echo "unconfirmed: --".$list_of_unconfirmed."--<br>\n";
#			echo "<br>\n";						
			$message = "";
			if( strlen( trim( $list_of_confirmed ) ) > 0 ) {
				$query = $this->db->query('UPDATE sdp_tr SET confirmed_ok = 1, confirmed_by = "'.$this->session->userdata('username').'" , confirmed = "'.date( "Y-m-d H:i:s", time() ).'" WHERE id IN ('.$list_of_confirmed.')');
				$query = $this->db->query('SELECT tr_number FROM sdp_tr WHERE id IN ('.$list_of_confirmed.')');
				$listOfTRsAsString="";
				foreach ($query->result_array() as $row)
				{
					$listOfTRsAsString = $listOfTRsAsString.",".$row['tr_number'];
				}
				$message="Confirmed TRs (".$listOfTRsAsString.")\n";
			}
			if( strlen( trim( $list_of_unconfirmed ) ) > 0 ) {
				$query = $this->db->query('UPDATE sdp_tr SET confirmed_ok = 0, confirmed_by = "'.$this->session->userdata('username').'" , confirmed = "'.date( "Y-m-d H:i:s", time() ).'" WHERE id IN ('.$list_of_unconfirmed.')');
				$query = $this->db->query('SELECT tr_number FROM sdp_tr WHERE id IN ('.$list_of_unconfirmed.')');
				$listOfTRsAsString="";
				foreach ($query->result_array() as $row)
				{
					$listOfTRsAsString = $listOfTRsAsString.",".$row['tr_number'];
				}
				$message = $message."Unconfirmed TRs (".$listOfTRsAsString.")";
			}
			
			$data = array(
				'release_id' => $this->input->post('id'),
				'submitted_by' => $this->session->userdata('username'),
				'submitted' => date( "Y-m-d H:i:s", time() ),
				'message' => $message
			);
			$this->db->insert('sdp_comment', $data);
			sdp::markReleaseAsModified( $this->input->post('id') );
			header("Location: "."/sdp/viewrelease/".$release_id);
		}
	}
	
	
	function deletetrs($release_id) {
		$pagedata = array();
		$pagedata['formname'] = '';
		$pagedata['id'] =  $release_id;
		$pagedata['errortext'] = '';
		$pagedata['trlist'] = '';
		$pagedata['tag'] = '';
		$pagedata['header'] = '';
		$errortext = "";
		
		if ($this->session->userdata('logged_in') != TRUE) {
			sdp::login( uri_string() );
			return;
	    }
	
		if( $this->input->post('submit') == FALSE ) {
			$query = $this->db->query('SELECT id,header FROM sdp_release WHERE id = '.$release_id);
			if ($query->num_rows() > 0)	{
					$release = $query->result_array();		
					$pagedata['header'] = $release[0]['header'];
			}
			## List all TRs for this release
			$trs = array();
			$query = $this->db->query('SELECT id,tr_number,submitted_by,deleted FROM sdp_tr where release_id ='.$release_id.' ORDER BY tr_number' );	
			$i=0;
			foreach ($query->result_array() as $row)
			{
				$trs[$i] = $row;
				$i++;
			}
			$pagedata['trs'] =  $trs;
			
			$this->load->view('sdp_header', $pagedata); 
			$this->load->view('sdp_delete_trs', $pagedata); 
			$this->load->view('sdp_footer');			
			return;
		} else {
			## act on change in the tr-list, i.e. delete or un-delete
			$deletedHash = array();
			$deleted = $this->input->post('deleted');
			$count=count($deleted);
			for($i=0;$i<$count;$i++){ 
				$deletedHash[ $deleted[$i] ] = 1;				
			}

			$list_of_deleted = "";
			$list_of_undeleted = "";
			$query = $this->db->query('SELECT id,deleted FROM sdp_tr where release_id ='.$release_id.' ORDER BY id' );	
			$i=0;
			foreach ($query->result_array() as $row)
			{
				if( array_key_exists( $row['id'], $deletedHash ) ) {
					if( $row['deleted'] <= 0 ) {
						// This means that the TR was previously NOT deleted and thus has just been set to DELETED
						if( strlen( trim( $list_of_deleted ) ) <= 0 ) {
							$list_of_deleted = $row['id'];
						} else {
							$list_of_deleted = $list_of_deleted.",".$row['id'];
						}
					}
				} else {
					if( $row['deleted'] > 0 ) {
						// This means that BEFORE it was set to DELETED and NOW it is not, lets UN-DELETE it
						if( strlen( trim( $list_of_undeleted ) ) <= 0 ) {
							$list_of_undeleted = $row['id'];
						} else {
							$list_of_undeleted = $list_of_undeleted.",".$row['id'];
						}
					}
				}
				$i++;
			}
			$message="";
			if( strlen( trim( $list_of_deleted ) ) > 0 ) {
				$query = $this->db->query('UPDATE sdp_tr SET deleted = 1  WHERE id IN ('.$list_of_deleted.')');
				$query = $this->db->query('SELECT tr_number FROM sdp_tr WHERE id IN ('.$list_of_deleted.')');
				$listOfTRsAsString="";
				foreach ($query->result_array() as $row)
				{
					$listOfTRsAsString = $listOfTRsAsString.",".$row['tr_number'];
				}
				$message=$message."Deleted TRs (".$listOfTRsAsString.")\n";
			}
			if( strlen( trim( $list_of_undeleted ) ) > 0 ) {
				$query = $this->db->query('UPDATE sdp_tr SET deleted = 0 WHERE id IN ('.$list_of_undeleted.')');
				$query = $this->db->query('SELECT tr_number FROM sdp_tr WHERE id IN ('.$list_of_undeleted.')');
				$listOfTRsAsString="";
				foreach ($query->result_array() as $row)
				{
					$listOfTRsAsString = $listOfTRsAsString.",".$row['tr_number'];
				}
				$message = $message."Undeleted TRs (".$listOfTRsAsString.")";
			}

			$data = array(
				'release_id' => $this->input->post('id'),
				'submitted_by' => $this->session->userdata('username'),
				'submitted' => date( "Y-m-d H:i:s", time() ),
				'message' => $message
			);
			$this->db->insert('sdp_comment', $data); 					
                        sdp::markReleaseAsModified( $this->input->post('id') );
			header("Location: "."/sdp/viewrelease/".$release_id);			
		}
	}
	
	
	function tagtrs($release_id) {
		$pagedata = array();
		$pagedata['formname'] = '';
		$pagedata['id'] =  $release_id;
		$pagedata['errortext'] = '';
		$pagedata['trlist'] = '';
		$pagedata['tag'] = '';
		$pagedata['header'] = '';
		$errortext = "";
		
		if ($this->session->userdata('logged_in') != TRUE) {
			sdp::login( uri_string() );
			return;
	    }
	
		if( $this->input->post('submit') == FALSE ) {
			$query = $this->db->query('SELECT id,header FROM sdp_release WHERE id = '.$release_id);
			if ($query->num_rows() > 0)	{
					$release = $query->result_array();		
					$pagedata['header'] = $release[0]['header'];
			}
			## List all TRs for this release
			$trs = array();
			$query = $this->db->query('SELECT id,tr_number,submitted_by,deleted,tag FROM sdp_tr where release_id ='.$release_id.' ORDER BY tr_number' );
			$i=0;
			foreach ($query->result_array() as $row)
			{
				$trs[$i] = $row;
				$i++;
			}
			$pagedata['trs'] =  $trs;
			
			$this->load->view('sdp_header', $pagedata); 
			$this->load->view('sdp_tag_trs', $pagedata); 
			$this->load->view('sdp_footer');			
			return;
		} else {
			## act on change in the tr-list, i.e. delete or un-delete
			$listOfIds="";
			$newtags = $this->input->post('newtag');
			$count=count($newtags);
			for($i=0;$i<$count;$i++){ 
				if( strlen( trim( $listOfIds ) ) <= 0 ) {
					$listOfIds = $newtags[$i];
				} else {
					$listOfIds = $listOfIds.",".$newtags[$i];
				}

			}
			if( strlen( trim( $listOfIds ) ) > 0 ) {
				$query = $this->db->query('UPDATE sdp_tr SET tag = "'.$this->input->post('tag').'"  WHERE id IN ('.$listOfIds.')');
				
				$query = $this->db->query('SELECT tr_number FROM sdp_tr WHERE id IN ('.$listOfIds.')');
				$listOfTRsAsString="";
				foreach ($query->result_array() as $row)
				{
					$listOfTRsAsString = $listOfTRsAsString.",".$row['tr_number'];
				}
				$message="Tagged TRs with \"".$this->input->post('tag')."\" (".$listOfTRsAsString.")";
				$data = array(
					'release_id' => $this->input->post('id'),
					'submitted_by' => $this->session->userdata('username'),
					'submitted' => date( "Y-m-d H:i:s", time() ),
					'message' => $message
				);
				$this->db->insert('sdp_comment', $data);
				sdp::markReleaseAsModified( $this->input->post('id') );
			}
			$uri="/sdp/viewrelease/".$release_id;
			header("Location: ".$uri);
		}
	}

	function movetrs($release_id) {
		$pagedata = array();
		$pagedata['formname'] = '';
		$pagedata['id'] =  $release_id;
		$pagedata['errortext'] = '';
		$pagedata['trlist'] = '';
		$pagedata['tag'] = '';
		$pagedata['header'] = '';
		$errortext = "";
		
		if ($this->session->userdata('logged_in') != TRUE) {
			sdp::login( uri_string() );
			return;
	    }
	
		if( $this->input->post('submit') == FALSE ) {
			$query = $this->db->query('SELECT id,header FROM sdp_release WHERE id = '.$release_id);
			if ($query->num_rows() > 0)	{
					$release = $query->result_array();		
					$pagedata['header'] = $release[0]['header'];
			}
			## List all TRs for this release
			$trs = array();
			$query = $this->db->query('SELECT id,tr_number,submitted_by,deleted,tag FROM sdp_tr where release_id ='.$release_id.' ORDER BY tr_number' );	
			$i=0;
			foreach ($query->result_array() as $row)
			{
				$trs[$i] = $row;
				$i++;
			}
			$pagedata['trs'] =  $trs;

			$releasearray = array();
			$query = $this->db->query('SELECT id, header FROM sdp_release');
	
			foreach ($query->result_array() as $row)
			{
				$releasearray[$row['id']]=$row['header'];
			}
			$pagedata['releasearray'] = $releasearray;											
			
			$this->load->view('sdp_header', $pagedata); 
			$this->load->view('sdp_move_trs', $pagedata); 
			$this->load->view('sdp_footer');			
			return;
		} else {
			## act on change in the tr-list, i.e. delete or un-delete
			if( $this->input->post('newrelease') != $release_id ) {
				// Lets update only if we have changed release
				$listOfIds="";
				$trlist = $this->input->post('trlist');
				$count=count($trlist);
				for($i=0;$i<$count;$i++){ 
					// There should really be a check here to make sure we do not add TRs that the new Release allready have...
					if( strlen( trim( $listOfIds ) ) <= 0 ) {
						$listOfIds = $trlist[$i];
					} else {
						$listOfIds = $listOfIds.",".$trlist[$i];
					}		
				}
				$message="";
				if( strlen( trim( $listOfIds ) ) > 0 ) {
					$query = $this->db->query('UPDATE sdp_tr SET release_id = "'.$this->input->post('newrelease').'"  WHERE id IN ('.$listOfIds.')');
					// Add history log info				
					$from_release = '-from-';		
					$to_release = '-to-';
					$query = $this->db->query('SELECT header FROM sdp_release WHERE id = '.$release_id);
					if ($query->num_rows() > 0)	{
							$release = $query->result_array();		
							$from_release = $release[0]['header'];
					}
					$query = $this->db->query('SELECT header FROM sdp_release WHERE id = '.$this->input->post('newrelease') );
					if ($query->num_rows() > 0)	{
							$release = $query->result_array();		
							$to_release = $release[0]['header'];
					}
					$query = $this->db->query('SELECT tr_number FROM sdp_tr WHERE id IN ('.$listOfIds.')');
					$listOfTRsAsString="";
					foreach ($query->result_array() as $row)
					{
						$listOfTRsAsString = $listOfTRsAsString.",".$row['tr_number'];
					}
					$message="Moved TRs from ".$from_release." to ".$to_release." (".$listOfTRsAsString.")";
				}
				$data = array(
					'release_id' => $this->input->post('id'),
					'submitted_by' => $this->session->userdata('username'),
					'submitted' => date( "Y-m-d H:i:s", time() ),
					'message' => $message
				);
				$this->db->insert('sdp_comment', $data);
				sdp::markReleaseAsModified( $this->input->post('id') );
				$data = array(
					'release_id' => $this->input->post('newrelease'),
					'submitted_by' => $this->session->userdata('username'),
					'submitted' => date( "Y-m-d H:i:s", time() ),
					'message' => $message
				);
				$this->db->insert('sdp_comment', $data);
                                sdp::markReleaseAsModified( $this->input->post('newrelease') );


			}
			header("Location: "."/sdp/viewrelease/".$release_id);
		}
	}
	
	function searchtr() {
		$tr = "HK56123";
		$sql = "SELECT tr_number, sdp_release.id, sdp_release.header, sdp_release.branch  FROM sdp_tr,sdp_release  where tr_number = '".$tr."' and sdp_tr.release_id = sdp_release.id ";
		
	}
	
	function maptrstoreleases() {
		$sql = "SELECT tr_number, sdp_release.id as release_id, sdp_release.header as header, sdp_release.branch as branch  FROM sdp_tr,sdp_release  WHERE sdp_tr.release_id = sdp_release.id AND sdp_tr.deleted = 0 ORDER BY tr_number DESC,header ";
		$query = $this->db->query( $sql );
		$listOfTrs = array();
		$previousTr = "";
		foreach ($query->result_array() as $row)
		{
			if( strcmp( trim( $previousTr ), trim( $row['tr_number'] ) ) == 0 ) {
				$listOfTrs[ $row['tr_number'] ] = $listOfTrs[ $row['tr_number'] ]."<a href=\"/sdp/viewrelease/".$row['release_id']."\">".$row['header']."</a> branch; ".$row['branch']."<br>";
			} else {
				$listOfTrs[ $row['tr_number'] ] = "<a href=\"/sdp/viewrelease/".$row['release_id']."\">".$row['header']."</a> branch; ".$row['branch']."<br>";
			}
			$previousTr = $row['tr_number'];
		}
		$pagedata['listOfTrs'] = $listOfTrs;
		$this->load->view('sdp_header', $pagedata); 
		$this->load->view('sdp_map_trs_to_releases', $pagedata); 
		$this->load->view('sdp_footer');
		return;		
	}
	
	function mappcstoreleases() {
		$sql = "SELECT pc_number, sdp_release.id as release_id, sdp_release.header as header, sdp_pc.comment as comment  FROM sdp_pc,sdp_release  WHERE sdp_pc.release_id = sdp_release.id ORDER BY pc_number,header";
		$query = $this->db->query( $sql );
		$listOfPCs = array();
		$previousPC = "";
		foreach ($query->result_array() as $row)
		{
			if( strcmp( trim( $previousPC ), trim( $row['pc_number'] ) ) == 0 ) {
				$listOfPCs[ $row['pc_number'] ] = $listOfPCs[ $row['pc_number'] ]."<a href=\"/sdp/viewrelease/".$row['release_id']."\">".$row['header']."</a> ".$row['comment']."<br>";
			} else {
				$listOfPCs[ $row['pc_number'] ] = "<a href=\"/sdp/viewrelease/".$row['release_id']."\">".$row['header']."</a> ".$row['comment']."<br>";
			}
			$previousPC = $row['pc_number'];
		}
		$pagedata['listOfPCs'] = $listOfPCs;
		$this->load->view('sdp_header', $pagedata);
		$this->load->view('sdp_map_pcs_to_releases', $pagedata);
		$this->load->view('sdp_footer');
		return;
	}


	function adddocument($release_id) {
		sdp::modifydocument($release_id);
	}
	
	function modifydocument($release_id,$doc_id=0) {
		$pagedata = array();
		$pagedata['formname'] = '';
		$pagedata['id'] =  $release_id;
		$pagedata['errortext'] = '';
		$pagedata['doc_id'] = $doc_id;
		$pagedata['doc_number'] = '';
		$pagedata['doc_revision'] = '';
		$pagedata['comment'] = '';
		$errortext = "";
		
		if ($this->session->userdata('logged_in') != TRUE) {
			sdp::login( uri_string() );
			return;
	    }
		
		$query = $this->db->query('SELECT id,header FROM sdp_release WHERE id = '.$release_id);
		if ($query->num_rows() > 0)	{
				$release = $query->result_array();		
				$pagedata['header'] = $release[0]['header'];
		}
	
		if( $this->input->post('submit') == FALSE ) {			
			if( $doc_id > 0 ) {
				$query = $this->db->query('SELECT id,release_id,doc_number,doc_revision,comment FROM sdp_document WHERE release_id = '.$release_id.' AND id = '.$doc_id );
				if ($query->num_rows() > 0)	{
					$row = $query->result_array();
					$pagedata['doc_id'] = $row[0]['id'];
					$pagedata['doc_number'] = $row[0]['doc_number'];
					$pagedata['doc_revision'] = $row[0]['doc_revision'];
					$pagedata['comment'] = $row[0]['comment'];
				}				
			}
			$this->load->view('sdp_header', $pagedata); 
			$this->load->view('sdp_add_document', $pagedata); 
			$this->load->view('sdp_footer');			
			return;
		} else {
			$doc_number = $this->input->post('doc_number');	
			$doc_revision = $this->input->post('doc_revision');
			$doc_id = $this->input->post('doc_id');
			$comment = $this->input->post('comment');

			if( $doc_id <= 0 ) {
				## This is a new doc, we are adding
				$query = $this->db->query('SELECT id FROM sdp_document WHERE release_id = '.$release_id.' AND doc_number = \''.$doc_number.'\'' );
				if ($query->num_rows() > 0)	{
					## Woops we have allready added this document to this release				
					$pagedata['doc_number'] = $doc_number;
					$pagedata['errortext'] = 'This document ('.$doc_number.') has allready been added to this release!';
					$this->load->view('sdp_header', $pagedata); 
					$this->load->view('sdp_add_document', $pagedata); 
					$this->load->view('sdp_footer');			
					return;
				} else {

					$data = array(
						'release_id' => $release_id,
						'submitted_by' => $this->session->userdata('username'),
						'submitted' => date( "Y-m-d H:i:s", time() ),
						'doc_number' => $doc_number,
						'comment' => $comment,
						'doc_revision' => $doc_revision
					);
					$this->db->insert('sdp_document', $data);

					
					## History
					$message="Added document $doc_number Rev $doc_revision";
					$data = array(
						'release_id' => $release_id,
						'submitted_by' => $this->session->userdata('username'),
						'submitted' => date( "Y-m-d H:i:s", time() ),
						'message' => $message
					);
					$this->db->insert('sdp_comment', $data);
					sdp::markReleaseAsModified( $release_id );
				}
			} else {
				## We are modifying an existing PC, should we REMOVE or MODIFY
				if( strcmp( $this->input->post('submit'), "Remove" ) == 0 ) {
					## History
					$doc_number = "document-number-failure!";
					$query = $this->db->query('SELECT doc_number FROM sdp_document WHERE id = '.$doc_id );
					if ($query->num_rows() > 0)	{
						$row = $query->result_array();
						$doc_number = $row[0]['doc_number'];
					}				
					$message="Removed Document; $doc_number";
					$data = array(
						'release_id' => $release_id,
						'submitted_by' => $this->session->userdata('username'),
						'submitted' => date( "Y-m-d H:i:s", time() ),
						'message' => $message
					);
					$this->db->insert('sdp_comment', $data);
					sdp::markReleaseAsModified( $release_id );
					$query = $this->db->query('DELETE FROM sdp_document WHERE id = '.$doc_id );
				} else {
					## We are modifying a doc information
					
					$query = $this->db->query('SELECT id,doc_number,doc_revision,comment FROM sdp_document WHERE id = '.$doc_id);
					$doc = $query->result_array();
					// print_r( $release );		
					$old = array();
					$old['id'] = $doc[0]['id'];
					$old['doc_number'] = $doc[0]['doc_number'];
					$old['doc_revision'] = $doc[0]['doc_revision'];
					$old['comment'] = $doc[0]['comment'];

					$data = array(
						'release_id' => $release_id,
						'submitted_by' => $this->session->userdata('username'),
						'submitted' => date( "Y-m-d H:i:s", time() ),
						'comment' => $comment,
						'doc_number' => $doc_number,
						'doc_revision' => $doc_revision
					);
					$this->db->where('id', $doc_id );
					$this->db->update('sdp_document', $data); 
	
					## History
					$message="Modified document $doc_number Rev $doc_revision, with comment; \n <em>$comment</em> \n";
					$message=$message."old info; \n";
					$message=$message.$old['doc_number']." Rev ".$old['doc_revision'].", with comment; \n<em>".$old['comment']."</em> ";
					$data = array(
						'release_id' => $release_id,
						'submitted_by' => $this->session->userdata('username'),
						'submitted' => date( "Y-m-d H:i:s", time() ),
						'message' => $message
					);
					$this->db->insert('sdp_comment', $data);
					sdp::markReleaseAsModified( $release_id );
				}
			}			
			header("Location: "."/sdp/viewrelease/".$release_id);			
		}
	}


	function editcomplementaryreleases($release_id) {
		$pagedata = array();
		$pagedata['formname'] = '';
		$pagedata['id'] =  $release_id;
		$pagedata['errortext'] = '';
		$pagedata['trlist'] = '';
		$pagedata['releases'] = '';
		$pagedata['header'] = '';
		$errortext = "";
		
		if ($this->session->userdata('logged_in') != TRUE) {
			sdp::login( uri_string() );
			return;
	    	}
	
		if( $this->input->post('submit') == FALSE ) {
			$query = $this->db->query('SELECT id,header FROM sdp_release WHERE id = '.$release_id);
			if ($query->num_rows() > 0)	{
					$release = $query->result_array();		
					$pagedata['header'] = $release[0]['header'];
			}
			## List all OPEN releases
			$releases = array();
			$query = $this->db->query('SELECT r.id,header,deliverydate,modified_timestamp,s.name as status_name FROM sdp_release r, sdp_release_status s WHERE status_id IN ( 1,2,3,4,5,8 ) AND r.status_id = s.id ORDER BY header' );	
			$i=0;
			foreach ($query->result_array() as $row)
			{
				$releases[$i] = $row;
				$i++;
			}
			$pagedata['releases'] =  $releases;

			## List all child releases to THIS release
			$linked_releases = array();
			$query = $this->db->query('SELECT child_release_id as id FROM sdp_complementary_release WHERE parent_release_id = '.$release_id );	
			foreach ($query->result_array() as $row)
			{
				$linked_releases[$row['id']] = 1;
			}
			$pagedata['linked_releases'] =  $linked_releases;
			
			$this->load->view('sdp_header', $pagedata); 
			$this->load->view('sdp_edit_child_releases', $pagedata); 
			$this->load->view('sdp_footer');			
			return;
		} else {
			## act on change in the release-list, i.e. link or unlink child releases
			$sql_in_statement = "";
			$childreleaseHash = array();
			$childrelease = $this->input->post('childrelease');
			$count=count($childrelease);
			for($i=0;$i<$count;$i++){ 
				$childreleaseHash[ $childrelease[$i] ] = 1;				
			}

			$list_of_childreleases = "";
			
			$query = $this->db->query('SELECT cr.child_release_id as id, r.header FROM sdp_complementary_release cr, sdp_release r WHERE cr.child_release_id = r.id AND parent_release_id ='.$release_id.' ORDER BY child_release_id' );	
			$i=0;
			$allready_linked_child_releases = array();
			foreach ($query->result_array() as $row)
			{
				$allready_linked_child_releases[ $row['id'] ]  = 1;
			}

			// Walk through and decide what NEW child releases we need to add
			$new_children = array_diff_key( $childreleaseHash, $allready_linked_child_releases );

			// Walk through and decide what child releases we should unlink from this release
			$children_to_unlink = array_diff_key( $allready_linked_child_releases, $childreleaseHash );
			
			$all_releases = array_merge( array_keys( $new_children ), array_keys( $children_to_unlink ) );

			$list_of_releases_as_string = "";
			foreach ($all_releases as $key)
        		{		
				$list_of_releases_as_string = $list_of_releases_as_string.$key.",";
			}

			$list_of_releases_as_string = rtrim( $list_of_releases_as_string, "," );


			$releases_and_names = array();
			$query = $this->db->query('SELECT id,header FROM sdp_release WHERE id IN ('.$list_of_releases_as_string.')');
			foreach ($query->result_array() as $row)
			{
				$releases_and_names[ $row['id'] ]  = $row['header'];
			}
			
			// Add the new children to this release
			foreach (array_keys($new_children) as $key)
        		{		
				$sql = "INSERT INTO sdp_complementary_release (parent_release_id,child_release_id) VALUES (".$release_id.",".$key.")";
				$query = $this->db->query( $sql );
			}

			// Remove / unlink the children we do not want anymore
			if( count(  $children_to_unlink ) > 0 )
			{
				$list_to_unlink = "";	
				foreach (array_keys($children_to_unlink) as $key)	
	        		{		
					$list_to_unlink = $list_to_unlink.$key.",";
				}
				$list_to_unlink = rtrim( $list_to_unlink, "," );
				$sql = "DELETE FROM sdp_complementary_release WHERE parent_release_id = ".$release_id." AND child_release_id IN (".$list_to_unlink.")";
				$query = $this->db->query( $sql );
			}


			$message = "Complementary releases modified.\n";
			if( count( array_keys($new_children) ) > 0 ) {
				foreach (array_keys($new_children) as $key)
        			{		
					$name = $releases_and_names[ $key ];
					$message = $message."Linking <A HREF=\"".site_url( '/sdp/viewrelease/'.$key)."\">\"".$name."\"</A>\n";
				}				
			}
			if( count( $children_to_unlink ) > 0 ) {
				foreach (array_keys($children_to_unlink) as $key)
        			{		
					$name = $releases_and_names[ $key ];
					$message = $message."Unlinking <A HREF=\"".site_url( '/sdp/viewrelease/'.$key)."\">\"".$name."\"</A>\n";
				}				
			}

			$data = array(
				'release_id' => $this->input->post('id'),
				'submitted_by' => $this->session->userdata('username'),
				'submitted' => date( "Y-m-d H:i:s", time() ),
				'message' => $message
			);
			$this->db->insert('sdp_comment', $data);
			sdp::markReleaseAsModified( $this->input->post('id') );
			header("Location: "."/sdp/viewrelease/".$release_id);
		}
	}



	function addpc($release_id) {
		sdp::modifypc($release_id);
	}
	
	function modifypc($release_id,$pc_id=0) {
		$pagedata = array();
		$pagedata['formname'] = '';
		$pagedata['id'] =  $release_id;
		$pagedata['errortext'] = '';
		$pagedata['pc_id'] = $pc_id;
		$pagedata['pc_number'] = '';
		$pagedata['comment'] = '';
		$pagedata['link'] = '';
		$errortext = "";
		
		if ($this->session->userdata('logged_in') != TRUE) {
			sdp::login( uri_string() );
			return;
	    }

		$query = $this->db->query('SELECT id,header FROM sdp_release WHERE id = '.$release_id);
		if ($query->num_rows() > 0)	{
				$release = $query->result_array();		
				$pagedata['header'] = $release[0]['header'];
		}

	
		if( $this->input->post('submit') == FALSE ) {			
			if( $pc_id > 0 ) {
				$query = $this->db->query('SELECT id,release_id,pc_number,link,comment FROM sdp_pc WHERE release_id = '.$release_id.' AND id = '.$pc_id );
				if ($query->num_rows() > 0)	{
					$row = $query->result_array();
					$pagedata['pc_id'] = $row[0]['id'];
					$pagedata['pc_number'] = $row[0]['pc_number'];
					$pagedata['link'] = $row[0]['link'];
					$pagedata['comment'] = $row[0]['comment'];
				}				
			}
			$this->load->view('sdp_header', $pagedata); 
			$this->load->view('sdp_add_pc', $pagedata); 
			$this->load->view('sdp_footer');			
			return;
		} else {
			$pc_number = $this->input->post('pc_number');
			$link = $this->input->post('link');
			$pc_id = $this->input->post('pc_id');
			$comment = $this->input->post('comment');
			if( $pc_id <= 0 ) {
				## This is a new PC, we are adding
				$query = $this->db->query('SELECT id FROM sdp_pc WHERE release_id = '.$release_id.' AND pc_number = \''.$pc_number.'\'' );
				if ($query->num_rows() > 0)	{
					## Woops we have allready added this PC to this release
					$pagedata['pc_number'] = $pc_number;
					$pagedata['link'] = $link;
					$pagedata['errortext'] = 'This PC ('.$pc_number.') has allready been added to this release!';
					$this->load->view('sdp_header', $pagedata); 
					$this->load->view('sdp_add_pc', $pagedata); 
					$this->load->view('sdp_footer');
					return;
				} else {
					$data = array(
						'release_id' => $release_id,
						'submitted_by' => $this->session->userdata('username'),
						'submitted' => date( "Y-m-d H:i:s", time() ),
						'link' => $link,
						'comment' => $comment,
						'pc_number' => $pc_number
					);
					$this->db->insert('sdp_pc', $data);

					## History
					$message="Added PC $pc_number";
					$data = array(
						'release_id' => $release_id,
						'submitted_by' => $this->session->userdata('username'),
						'submitted' => date( "Y-m-d H:i:s", time() ),
						'message' => $message
					);
					$this->db->insert('sdp_comment', $data);
					sdp::markReleaseAsModified( $release_id );
				}
			} else {
				## We are modifying an existing PC, should we REMOVE or MODIFY
				if( strcmp( $this->input->post('submit'), "Remove" ) == 0 ) {
					## History
					$pc_number = "pc-number-failure!";
					$query = $this->db->query('SELECT pc_number FROM sdp_pc WHERE id = '.$pc_id );
					if ($query->num_rows() > 0)	{
						$row = $query->result_array();
						$pc_number = $row[0]['pc_number'];
					}				
					$message="Removed PC $pc_number";
					$data = array(
						'release_id' => $release_id,
						'submitted_by' => $this->session->userdata('username'),
						'submitted' => date( "Y-m-d H:i:s", time() ),
						'message' => $message
					);
					$this->db->insert('sdp_comment', $data);
					sdp::markReleaseAsModified( $release_id );
					$query = $this->db->query('DELETE FROM sdp_pc WHERE id = '.$pc_id );
				} else {				
					## We are modifying a PC information
					$data = array(
						'release_id' => $release_id,
						'submitted_by' => $this->session->userdata('username'),
						'submitted' => date( "Y-m-d H:i:s", time() ),
						'comment' => $comment,
						'link' => $link,
						'pc_number' => $pc_number
					);
					$this->db->where('id', $pc_id );
					$this->db->update('sdp_pc', $data);
	
					## History
					$message="Modified PC $pc_number old info; ...";
					$data = array(
						'release_id' => $release_id,
						'submitted_by' => $this->session->userdata('username'),
						'submitted' => date( "Y-m-d H:i:s", time() ),
						'message' => $message
					);
					$this->db->insert('sdp_comment', $data);
					sdp::markReleaseAsModified( $release_id );
				}
			}
			
			header("Location: "."/sdp/viewrelease/".$release_id);			
		}
	}
	
	
	function addcr($release_id) {
		sdp::modifycr($release_id);
	}
	
	function modifycr($release_id,$cr_id=0) {
		$pagedata = array();
		$pagedata['formname'] = '';
		$pagedata['id'] =  $release_id;
		$pagedata['errortext'] = '';
		$pagedata['cr_id'] = $cr_id;
		$pagedata['cr_number'] = '';
		$pagedata['comment'] = '';
		$pagedata['link'] = '';
		$errortext = "";

		if ($this->session->userdata('logged_in') != TRUE) {
			sdp::login( uri_string() );
			return;
	    }

		$query = $this->db->query('SELECT id,header FROM sdp_release WHERE id = '.$release_id);
		if ($query->num_rows() > 0)	{
				$release = $query->result_array();
				$pagedata['header'] = $release[0]['header'];
		}


		if( $this->input->post('submit') == FALSE ) {
			if( $cr_id > 0 ) {
				$query = $this->db->query('SELECT id,release_id,cr_number,link,comment FROM sdp_cr WHERE release_id = '.$release_id.' AND id = '.$cr_id );
				if ($query->num_rows() > 0)	{
					$row = $query->result_array();
					$pagedata['cr_id'] = $row[0]['id'];
					$pagedata['cr_number'] = $row[0]['cr_number'];
					$pagedata['link'] = $row[0]['link'];
					$pagedata['comment'] = $row[0]['comment'];
				}				
			}
			$this->load->view('sdp_header', $pagedata); 
			$this->load->view('sdp_add_cr', $pagedata);
			$this->load->view('sdp_footer');			
			return;
		} else {
			$cr_number = $this->input->post('cr_number');
			$link = $this->input->post('link');
			$cr_id = $this->input->post('cr_id');
			$comment = $this->input->post('comment');
			if( $cr_id <= 0 ) {
				## This is a new CR, we are adding
				$query = $this->db->query('SELECT id FROM sdp_cr WHERE release_id = '.$release_id.' AND cr_number = \''.$cr_number.'\'' );
				if ($query->num_rows() > 0)	{
					## Woops we have allready added this CR to this release
					$pagedata['cr_number'] = $cr_number;
					$pagedata['link'] = $link;
					$pagedata['errortext'] = 'This CR ('.$cr_number.') has allready been added to this release!';
					$this->load->view('sdp_header', $pagedata); 
					$this->load->view('sdp_add_cr', $pagedata);
					$this->load->view('sdp_footer');
					return;
				} else {
					$data = array(
						'release_id' => $release_id,
						'submitted_by' => $this->session->userdata('username'),
						'submitted' => date( "Y-m-d H:i:s", time() ),
						'link' => $link,
						'comment' => $comment,
						'cr_number' => $cr_number
					);
					$this->db->insert('sdp_cr', $data);

					## History
					$message="Added CR $cr_number";
					$data = array(
						'release_id' => $release_id,
						'submitted_by' => $this->session->userdata('username'),
						'submitted' => date( "Y-m-d H:i:s", time() ),
						'message' => $message
					);
					$this->db->insert('sdp_comment', $data);
					sdp::markReleaseAsModified( $release_id );
				}
			} else {
				## We are modifying an existing CR, should we REMOVE or MODIFY
				if( strcmp( $this->input->post('submit'), "Remove" ) == 0 ) {
					## History
					$cr_number = "cr-number-failure!";
					$query = $this->db->query('SELECT cr_number FROM sdp_cr WHERE id = '.$cr_id );
					if ($query->num_rows() > 0)	{
						$row = $query->result_array();
						$cr_number = $row[0]['cr_number'];
					}				
					$message="Removed CR $cr_number";
					$data = array(
						'release_id' => $release_id,
						'submitted_by' => $this->session->userdata('username'),
						'submitted' => date( "Y-m-d H:i:s", time() ),
						'message' => $message
					);
					$this->db->insert('sdp_comment', $data);
					sdp::markReleaseAsModified( $release_id );
					$query = $this->db->query('DELETE FROM sdp_cr WHERE id = '.$cr_id );
				} else {				
					## We are modifying a CR information
					$data = array(
						'release_id' => $release_id,
						'submitted_by' => $this->session->userdata('username'),
						'submitted' => date( "Y-m-d H:i:s", time() ),
						'comment' => $comment,
						'link' => $link,
						'cr_number' => $cr_number
					);
					$this->db->where('id', $cr_id );
					$this->db->update('sdp_cr', $data);
	
					## History
					$message="Modified CR $cr_number old info; ...";
					$data = array(
						'release_id' => $release_id,
						'submitted_by' => $this->session->userdata('username'),
						'submitted' => date( "Y-m-d H:i:s", time() ),
						'message' => $message
					);
					$this->db->insert('sdp_comment', $data);
					sdp::markReleaseAsModified( $release_id );
				}
			}
			
			header("Location: "."/sdp/viewrelease/".$release_id);			
		}
	}

	
	function trspecificcomment($release_id,$tr_id=0) {
		$pagedata = array();
		$pagedata['formname'] = '';
		$pagedata['id'] =  $release_id;
		$pagedata['errortext'] = '';
		$pagedata['tr_id'] = $tr_id;
		$pagedata['tr_number'] = '';
		$pagedata['tr_title'] = '';
		$errortext = "";
		
		if ($this->session->userdata('logged_in') != TRUE) {
			sdp::login( uri_string() );
			return;
	    }
	
		$query = $this->db->query('SELECT id,header FROM sdp_release WHERE id = '.$release_id);
		if ($query->num_rows() > 0)	{
				$release = $query->result_array();		
				$pagedata['header'] = $release[0]['header'];
		}
		
		if( $this->input->post('submit') == FALSE ) {			
			if( $tr_id > 0 ) {
				$query = $this->db->query('SELECT id,tr_number,comment FROM sdp_tr WHERE id = '.$tr_id );
				if ($query->num_rows() > 0)	{
					$row = $query->result_array();
					$pagedata['tr_number'] = $row[0]['tr_number'];
					$pagedata['comment'] = $row[0]['comment'];
					$pagedata['tr_title'] = 'test text'; // $row[0]['tr_title'];
				}				
			} else {
				$pagedata['errortext'] = 'ERROR! No TR-number given!';
			}
			$this->load->view('sdp_header', $pagedata); 
			$this->load->view('sdp_tr_specific_comment', $pagedata);
			$this->load->view('sdp_footer');			
			return;
		} else {
			## Lets modify the TR comment
			$data = array(
				'comment' => $this->input->post('comment')
			);
			$this->db->where('id', $tr_id );
			$this->db->update('sdp_tr', $data); 

			## History
			$message="Modified TR(".$this->input->post('tr_number').") specific comment; \"".$this->input->post('comment')."\"";
			$data = array(
				'release_id' => $release_id,
				'submitted_by' => $this->session->userdata('username'),
				'submitted' => date( "Y-m-d H:i:s", time() ),
				'message' => $message
			);
			$this->db->insert('sdp_comment', $data);
			sdp::markReleaseAsModified( $release_id );
			header("Location: "."/sdp/viewrelease/".$release_id);			
		}
	}


	function rss() 
	{
		$this->load->view('sdp_header');
		$this->load->view('sdp_rss_feeds');
		$this->load->view('sdp_footer');
	}
	
        function updatetrstatus() {
                ##
                ## MHWeb info
                ##
                $base_url = 'http://mhweb1.al.sw.ericsson.se:7040/scripts/servlet/servletTrSearch?OutputFormat=extended&Eriref=';
                $username = 'readonly';
                $password = '';


                $sql="SELECT tr_number FROM sdp_tr_status WHERE status not like '%FI%'";
                $query = $this->db->query( $sql );

		foreach ($query->result_array() as $row)
		{
			$tr = $row['tr_number'];
			$url = $base_url.$tr;
                        $content = sdp::http_auth_get($url,$username,$password);
                        $rows = preg_split("/[\n\r]/", $content, -1, PREG_SPLIT_NO_EMPTY );
                        $keys = preg_split("/;/", $rows[0], -1, PREG_SPLIT_NO_EMPTY );
                        $values = preg_split("/;/", $rows[1], -1, PREG_SPLIT_NO_EMPTY );
                        if( count( $values ) != count( $keys ) ) {
                               echo "Unable to retrive information about TR($tr)!<br>";
                               $data = array(
          			      'title' => '--- failed to get TR info ---',
          			      'prio' => 'N/A',
          			      'status' => 'N/A',
          			      'answer' => 'N/A',
          			      'registred' => 'N/A',
          			      'updated' => date( "Y-m-d H:i:s", time() )
              			);
                        } else {
                               $trinfo = array_combine( $keys, $values );
                               $data = array(
          			      'title' => trim( $trinfo['"Heading"'], '"' ),
          			      'prio' => trim( $trinfo['"Priority"'], '"' ),
          			      'status' => trim( $trinfo['"Status"'], '"' ),
          			      'answer' => trim( $trinfo['"Answer code"'], '"' ),
          			      'registred' => trim( $trinfo['"Register date"'], '"' ),
          			      'updated' => date( "Y-m-d H:i:s", time() )
              			);
                        }
			$this->db->where('tr_number', $tr );
			$this->db->update('sdp_tr_status', $data);

                        echo "$tr updated<br>";
#                        foreach( $trinfo as $key=>$value ) {
#                                 echo "$key = $value<br>";
#                        }
		}
        }

        function http_auth_get($url,$username,$password){
              $cred = sprintf('Authorization: Basic %s', base64_encode("$username:$password") );
              $opts = array(
                'http'=>array(
                'method'=>'GET',
                'header'=>$cred)
              );
              $ctx = stream_context_create($opts);
              $handle = fopen ( $url, 'r', false, $ctx);
              $str = stream_get_contents($handle);
              return $str;
        }


        function loadicpdata() {
          
                 /*
                  In case we need to empty the database
                    delete from sdp_document;
                    delete from sdp_comment;
                    delete from sdp_pc;
                    delete from sdp_release;
                    delete from sdp_tr;
                    delete from sdp_tr_status;
                  */

                 $filename="/proj/up/opt/www-root/usefulscripts/sdp_icp_content.txt";
       	         $handle = fopen($filename, "r");
                 $filecontent = fread($handle, filesize($filename));
	         fclose($handle);

                 $release_id = 0;
                 $releasename="";
                 $DeliveryDate="";
                 $ContentFreeze="";
                 $CodeFreeze="";
                 $Comment="";
                 $Delivered=0;
                 $first_tr_found = 0;
                 $linearray = explode("\n",$filecontent);
                 $linenumber = 1;
                 foreach($linearray as $line){
                                    if( preg_match( "/^#/", $line ) ) {
                                      // skip
                                    } else if( preg_match( "/^\[/", $line ) ) {
                                      // found Release
                                      $releasename= trim( trim( $line ), "\[\]" );
                                      echo "release name: ".$releasename."<br>";
                                      $release_id = 0;
                                      $DeliveryDate="";
                                      $ContentFreeze="";
                                      $CodeFreeze="";
                                      $Comment="";
                                      $Delivered=0;
                                      $first_tr_found = 0;
                                    } else if( preg_match( "/^Delivered/i", $line ) ) {
                                      $Delivered=1;
                                    }
                                    else if( preg_match( "/^DeliveryDate/i", $line ) ) {
                                      // found Release
                                      $arr = split( ":", $line );
                                      $DeliveryDate=$arr[1];
                                    } else if( preg_match( "/^ContentFreeze/i", $line ) ) {
                                      // found Release
                                      $arr = split( ":", $line );
                                      $ContentFreeze=$arr[1];
                                    } else if( preg_match( "/^CodeFreeze/i", $line ) ) {
                                      // found Release
                                      $arr = split( ":", $line );
                                      $CodeFreeze=$arr[1];
                                    } else if( preg_match( "/^Status/i", $line ) ) {
                                      // found Release
                                      $arr = split( ":", $line );
                                      $Comment=$Comment." ".$arr[1];
                                    } else if( preg_match( "/^Comment/i", $line ) ) {
                                      // found Release
                                      $arr = split( ":", $line );
                                      $Comment=$Comment." ".$arr[1];
                                    } else if( preg_match( "/^TR/i", $line ) ) {
                                      // found TR
                                      if( $first_tr_found == 0 ) {
                                          // So the info about the release is complete... lets create it in the db
                                          if( $Delivered > 0 ) $release_status = 6;
                                          else $release_status = 2;
                                          $data = array(
          					'header' => $releasename,
          					'branch' => '- not defined -',
          					'status_id' => $release_status,
          					'contentfreeze' => $ContentFreeze,
          					'codefreeze' => $CodeFreeze,
          					'deliverydate' => $DeliveryDate,
          					'lsvdeliverydate' => '1970-01-01',
          					'modified_by' => '- script -',
          					'comment' => trim( $Comment ),
          					'modified_timestamp' => date( "Y-m-d H:i:s", time() )
					);
          				$this->db->insert('sdp_release', $data);
          				$query = $this->db->query('SELECT id,header,branch,comment,status_id,contentfreeze,codefreeze,deliverydate,lsvdeliverydate FROM sdp_release ORDER BY id DESC LIMIT 1');
        				if ($query->num_rows() > 0)	{
        					$release = $query->result_array();
        					$release_id = $release[0]['id'];
        				}
                                        $first_tr_found = 1;
                                      }
                                      $arr = split( ":", $line );
                                      $tr = trim( $arr[1] );
                                      $tr_comment = '';
                                      if( count( $arr ) > 2 ) {
                                          $tr_comment = trim( $arr[2] );
                                      }
                                      $data = array(
					'release_id' => $release_id,
					'tag' => '',
					'comment' => $tr_comment,
					'tr_number' => $tr,
					'submitted_by' => '- script -',
					'submitted' => date( "Y-m-d H:i:s", time() ),
					'confirmed_ok' => 0,
					'deleted' => 0,
                                      );
				      $this->db->insert('sdp_tr', $data);
				      ## Insert the TR in the sdp_tr_status table, so that we can get status info about it
				      $sql = "INSERT IGNORE INTO sdp_tr_status (tr_number, title, prio, status, answer, registred, updated ) values ( '".$tr."','- TR needs to be updated -', 'N/A', 'N/A', 'N/A', '1970-01-01', '".date( "Y-m-d H:i:s", time() )."' )";
           			      $query = $this->db->query( $sql );
                                    }  else if( preg_match( "/^PC/i", $line ) ) {
                                        $arr = split( ":", $line );
                                        $pc_number = trim( $arr[1] );
                                        $pc_link = '';
                                        $pc_comment = '';
                                        if( count( $arr ) > 2 ) {
                                            $pc_link = trim( $arr[2] );
                                        }
                                        if( count( $arr ) > 3 ) {
                                            $pc_comment = trim( $arr[3] );
                                        }
                                        $data = array(
						'release_id' => $release_id,
						'submitted_by' => '- script -',
						'submitted' => date( "Y-m-d H:i:s", time() ),
						'pc_number' => $pc_number,
						'link' => $pc_link,
						'comment' => $pc_comment
					);
					$this->db->insert('sdp_pc', $data);

                                    }  else if( preg_match( "/^DOC/i", $line ) ) {
                                        $arr = split( ":", $line );
                                        $doc_number = trim( $arr[1] );
                                        $doc_revision = '';
                                        $doc_comment = '';
                                        if( count( $arr ) > 2 ) {
                                            $doc_revision = trim( $arr[2] );
                                        }
                                        if( count( $arr ) > 3 ) {
                                            $pc_comment = trim( $arr[3] );
                                        }
                                        $data = array(
						'release_id' => $release_id,
						'submitted_by' => '- script -',
						'submitted' => date( "Y-m-d H:i:s", time() ),
						'comment' => $doc_comment,
						'doc_number' => $doc_number,
						'doc_revision' => $doc_revision
					);
					$this->db->insert('sdp_document', $data);

                                    } else {
                                      if( strlen( trim( $line ) ) > 0 ) {
                                          echo "unable to interpret line ".$linenumber.": ---".$line."---<br>";
                                      }
                                    }
                                    $linenumber = $linenumber + 1;
                                #echo $line."<br>";
                 }

        }

}

?>
