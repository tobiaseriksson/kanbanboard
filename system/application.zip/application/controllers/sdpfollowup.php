<?php

class sdpfollowup extends Controller {
    function sdpfollowup()    {
		parent::Controller();
		$this->load->database();
		$this->load->helper('xml');
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->plugin('js_calendar');
		$this->load->helper('form');
	}
	


	function index()    {
		sdpfollowup::viewallfollowups();
	}
	

	function logout() {
		$this->session->sess_destroy();
                sdpfollowup::index();
	}

	function login($redirect_to_url='')
	{
		$pagedata['errormessage'] = '';
		$pagedata['redirect_to_url'] = $redirect_to_url;
                if( strlen( trim( $redirect_to_url ) ) <= 0 ) {
                    $redirect_to_url = "/sdpfollowup";
                    $pagedata['redirect_to_url'] = $redirect_to_url;
                }
                if( strlen( trim( $this->input->post('redirect_to_url') ) ) > 0 ) {
                  $pagedata['redirect_to_url'] = $this->input->post('redirect_to_url');
                  $redirect_to_url = $this->input->post('redirect_to_url');
                }

		// check to see if we are loging in or if we are viewing the login page
		if( $this->input->post('username') == FALSE ) {
			$this->load->view('followup/sdp_header');
			$this->load->view('followup/sdp_login',$pagedata);
			$this->load->view('followup/sdp_footer');
			return;
		}
                 // echo "#url=".$redirect_to_url."<br>";
                 // return;

		// verify username and password in the database
		$md5password = md5( $this->input->post('password') );
		$query = $this->db->query("SELECT username FROM sdp_user WHERE password = '".$md5password."' AND username = '".$this->input->post('username')."'");
		if ($query->num_rows() <= 0)
		{
			// Oops! no such user
			$pagedata['errormessage'] = 'Sorry wrong username or password!';
			$this->load->view('followup/sdp_header');
			$this->load->view('followup/sdp_login',$pagedata);
			$this->load->view('followup/sdp_footer');
			return;
		}
		// Set session / login OK
		$this->session->set_userdata('username', $this->input->post('username'));
		$this->session->set_userdata('logged_in', 'TRUE');

		header("Location: ".$redirect_to_url );
	}

       function statistics() {

                $sql = "SELECT count(tr_number) as total, team, date_format( implemented, '%Y %v' )  as year_and_week FROM sdp_tr_followup f, sdp_user u WHERE  f.username = u.username AND implemented is not null group by concat( team, date_format( implemented, '%y%v' ) ) order by year_and_week,team";
                $query = $this->db->query( $sql );
		$i=0;
                $stats = array();
		foreach ($query->result_array() as $row)
		{
			$stats[$i] = $row;
			$i++;
		}
                $pagedata['stats'] = $stats;

                $sql="SELECT count(tr_number) as total, team, date_format( implemented, '%Y %M' )  as year_and_month FROM sdp_tr_followup f, sdp_user u WHERE  f.username = u.username AND implemented is not null group by concat( team, date_format( implemented, '%y%M' ) ) order by year_and_month,team";
                $query = $this->db->query( $sql );
		$i=0;
                $monthstats = array();
		foreach ($query->result_array() as $row)
		{
			$monthstats[$i] = $row;
			$i++;
		}
                $pagedata['monthstats'] = $monthstats;

                $this->load->view('followup/sdp_header',$pagedata);
		$this->load->view('followup/sdp_followup_statistics',$pagedata);
         	$this->load->view('followup/sdp_footer');
        }

        function viewallfollowups_sortby($sortby='',$team='') {
                if( strcmp( $sortby, "" ) == 0 ) {
                  $sortby = "tr_number";
                }
                $only_one_team = '';
                if( strcmp( $team, "" ) != 0 ) {
                  $only_one_team = "AND team = '$team' ";
                }
                if( strcmp( $team, "all" ) == 0 ) {
                  $only_one_team = " ";
                }
                $sql='SELECT id,tf.tr_number as tr_number,trs.title as title, trs.status as status,trs.prio as prio,analysis_started,testcase_ready_for_review,testcase_review_done,implemented,comment, DateDiff( ifnull(implemented, now() ),analysis_started ) as age, tf.username, team  FROM sdp_tr_followup tf, sdp_tr_status trs, sdp_user u WHERE tf.tr_number = trs.tr_number AND tf.username = u.username '.$only_one_team.' ORDER BY '.$sortby.' DESC';
                $query = $this->db->query( $sql );
		$i=0;
                $followups = array();
		foreach ($query->result_array() as $row)
		{
			$followups[$i] = $row;
			$i++;
		}

		$sql='SELECT DISTINCT team  FROM sdp_tr_followup tf, sdp_user u WHERE tf.username = u.username ORDER BY team DESC';
                $query = $this->db->query( $sql );
		$i=0;
                $teams = array();
		foreach ($query->result_array() as $row)
		{
			$teams[$i] = $row;
			$i++;
		}

                $pagedata['onlyteam'] = $team;
                $pagedata['teams'] = $teams;
                $pagedata['followups'] = $followups;
                $pagedata['username'] = $this->session->userdata('username');
                $this->load->view('followup/sdp_header',$pagedata);
		$this->load->view('followup/sdp_view_all_followups',$pagedata);
         	$this->load->view('followup/sdp_footer');
        }

        function viewallfollowups() {
                $sql='SELECT id,tf.tr_number as tr_number,trs.title as title, trs.status as status,trs.prio as prio,analysis_started,testcase_ready_for_review,testcase_review_done,implemented,comment, DateDiff( ifnull(implemented, now() ),analysis_started ) as age, tf.username, team  FROM sdp_tr_followup tf, sdp_tr_status trs, sdp_user u WHERE tf.tr_number = trs.tr_number AND tf.username = u.username AND tf.deleted = 0 ORDER BY tr_number DESC';
                # $sql = 'SELECT id,tf.tr_number as tr_number,trs.title as title, trs.status as status,trs.prio as prio,analysis_started,testcase_ready_for_review,testcase_review_done,implemented,comment, DateDiff( ifnull(implemented, now() ),analysis_started ) as age, username  FROM sdp_tr_followup tf, sdp_tr_status trs WHERE tf.tr_number = trs.tr_number ORDER BY tr_number DESC';
                $query = $this->db->query( $sql );
		$i=0;
                $followups = array();
		foreach ($query->result_array() as $row)
		{
			$followups[$i] = $row;
			$i++;
		}
		$sql='SELECT DISTINCT team  FROM sdp_tr_followup tf, sdp_user u WHERE tf.username = u.username ORDER BY team DESC';
                $query = $this->db->query( $sql );
		$i=0;
                $teams = array();
		foreach ($query->result_array() as $row)
		{
			$teams[$i] = $row;
			$i++;
		}

                $pagedata['onlyteam'] = "";
                $pagedata['teams'] = $teams;
                $pagedata['followups'] = $followups;
                $pagedata['username'] = $this->session->userdata('username');
                $this->load->view('followup/sdp_header',$pagedata);
		$this->load->view('followup/sdp_view_all_followups',$pagedata);
         	$this->load->view('followup/sdp_footer');
        }

        function setDateToNULLIfInvalid( $datestring ) {
         if( $datestring == null || strlen( trim( $datestring ) ) <= 0 || strcmp( "0000-00-00", trim( $datestring ) ) == 0 ) {
              $datestring = null;
         }
         return $datestring;
        }


    function addormodify($tr_number='',$errormessage='')
	{
		if ($this->session->userdata('logged_in') != TRUE) {
			sdpfollowup::login( uri_string() );
			return;
	        }

		// Lets fill in the some default data

        if($tr_number)
        {
            $pagedata['tr_number'] =$tr_number;
        }
        else
        {
            $pagedata['tr_number'] = 'HL00000'; 
        }

		$pagedata['id'] = 0;
		
		$pagedata['title'] = '';
		$pagedata['status'] = 'N/A';
		$pagedata['prio'] = 'N/A';
		$pagedata['comment'] = '';
		$pagedata['username'] = $this->session->userdata('username');
		$pagedata['analysis_started'] = date( "Y-m-d", time());
		#$pagedata['testcase_ready_for_review'] = date( "Y-m-d", time());
		#$pagedata['testcase_review_done'] = date( "Y-m-d", time());
		#$pagedata['implemented'] = date( "Y-m-d", time());
		$pagedata['testcase_ready_for_review'] = "";
		$pagedata['testcase_review_done'] = "";
		$pagedata['implemented'] = "";
		$pagedata['analysis_started_time'] = time();
		$pagedata['testcase_ready_for_review_time'] = time();
		$pagedata['testcase_review_done_time'] = time();
		$pagedata['implemented_time'] = time();
		$pagedata['history'] = array();
		$pagedata['formname'] = 'addormodifytrfollowup';
		$pagedata['errormessage'] = $errormessage;
		$usernamearray = array();
		$query = $this->db->query("SELECT username, concat( username, ' (', team, ')' ) as name_and_team  FROM sdp_user order by username");
		foreach ($query->result_array() as $row)
		{
         		$usernamearray[$row['username']]=$row['name_and_team'];
		}
		$pagedata['usernamearray'] = $usernamearray;

		// if the post return FALSE we know this is a request to ADD a new followu
		if( $this->input->post('submit') == FALSE && $this->input->post('Delete') == FALSE ){

		         if( strlen( trim( $tr_number ) ) > 0 ) {
                //fetch TR data
				$query = $this->db->query('SELECT id,trs.tr_number as tr_number, trs.title as title, trs.status as status, trs.prio as prio, comment,analysis_started,testcase_ready_for_review,testcase_review_done,implemented,username FROM sdp_tr_followup tf, sdp_tr_status trs WHERE tf.tr_number like \'%'.$tr_number.'%\' AND trs.tr_number = tf.tr_number');

				if ($query->num_rows() > 0)	{
					$release = $query->result_array();
					// print_r( $release );
          				$pagedata['id'] = $release[0]['id'];
          				$pagedata['tr_number'] = $release[0]['tr_number'];
          				$pagedata['title'] = $release[0]['title'];
          				$pagedata['status'] = $release[0]['status'];
          				$pagedata['prio'] = $release[0]['prio'];
          				$pagedata['comment'] = $release[0]['comment'];
          				$pagedata['username'] = $release[0]['username'];

                                        $analysis_started = $release[0]['analysis_started'];
                                        $pagedata['analysis_started'] = $analysis_started;
          				if( $analysis_started == null ) {
                                            $pagedata['analysis_started_time'] = time();
                                            $pagedata['analysis_started'] = "";
                                        } else {
					    $date_array = preg_split( "/[-\s]/", $analysis_started );
                                            $pagedata['analysis_started_time'] = mktime(0,0,0,$date_array[1],$date_array[2],$date_array[0]);
                                        }

                                        $pagedata['analysis_started'] = $release[0]['analysis_started'];
                                        $pagedata['analysis_started_time'] = sdpfollowup::prepareDateForJavascriptCalendar( $release[0]['analysis_started'] );

                                        $pagedata['testcase_ready_for_review'] = $release[0]['testcase_ready_for_review'];
                                        $pagedata['testcase_ready_for_review_time'] = sdpfollowup::prepareDateForJavascriptCalendar( $release[0]['testcase_ready_for_review'] );

                                        $pagedata['testcase_review_done'] = $release[0]['testcase_review_done'];
                                        $pagedata['testcase_review_done_time'] = sdpfollowup::prepareDateForJavascriptCalendar( $release[0]['testcase_review_done'] );

                                        $pagedata['implemented'] = $release[0]['implemented'];
                                        $pagedata['implemented_time'] = sdpfollowup::prepareDateForJavascriptCalendar( $release[0]['implemented'] );


          				$sql = "SELECT tr_number, sdp_release.id as release_id, sdp_release.header as header, sdp_release.branch as branch, submitted  FROM sdp_tr,sdp_release  WHERE sdp_tr.release_id = sdp_release.id AND sdp_tr.deleted = 0 AND tr_number like '%".$tr_number."%' ORDER BY tr_number,header";
                                        $query = $this->db->query( $sql );
                        		$i=0;
                        		$releases = array();
                        		foreach ($query->result_array() as $row)
                        		{
                        			$releases[$i] = $row;
                        			$i++;
                        		}
                        		$pagedata['releases'] =  $releases;
				
				$history = array();
                  		$query = $this->db->query('SELECT id,followup_id,message,submitted,submitted_by FROM sdp_tr_followup_history WHERE followup_id = '.$release[0]['id'].' ORDER BY submitted DESC' );
                  		$i=0;
                  		foreach ($query->result_array() as $row)
                  		{
                  			$history[$i] = $row;
                  			$i++;
                  		}
                  		$pagedata['history'] = $history;
                }       
			}
            
			$this->load->view('followup/sdp_header',$pagedata);
			$this->load->view('followup/sdp_add_tr_followup',$pagedata);
			$this->load->view('followup/sdp_footer');
		}
                else {
                        $id = $this->input->post('id');
                        $tr = trim( strtoupper( $this->input->post('tr_number') ) );
			$comment = $this->input->post('comment');
			$analysis_started = sdpfollowup::setDateToNULLIfInvalid( $this->input->post('analysis_started') );
            $testcase_ready_for_review = sdpfollowup::setDateToNULLIfInvalid( $this->input->post('testcase_ready_for_review') );
			$testcase_review_done = sdpfollowup::setDateToNULLIfInvalid( $this->input->post('testcase_review_done') );
			$implemented = sdpfollowup::setDateToNULLIfInvalid( $this->input->post('implemented') );
			$username = $this->input->post('username');
			if( $id == 0 ) {

				// id = 0, indicates that we are adding a new TR
				if( preg_match( "/^[a-z][a-z][0-9][0-9][0-9][0-9][0-9]$/i",$tr ) ) {
					## The TR matched the TR-format HK89123
					## Lets make sure we have not allready added it
					$query = $this->db->query("SELECT tr_number,id FROM sdp_tr_followup s where tr_number like '".$tr."'");
                                        if ($query->num_rows() > 0) {
                                           header("Location: "."/sdpfollowup/addormodify/".$tr."/Already Registred" );
                                           return;
                                        }
                                        ## See if it is allready in the status-table, we should not add it there twice...
					$query = $this->db->query("SELECT tr_number FROM sdp_tr_status WHERE tr_number = '".$tr."'");
		                        if ($query->num_rows() <= 0) {
						## Insert the TR in the sdp_tr_status table, so that we can get status info about it
						$sql = "INSERT IGNORE INTO sdp_tr_status (tr_number, title, prio, status, answer, registred, updated ) values ( '".$tr."','- TR needs to be updated -', 'N/A', 'N/A', 'N/A', '1970-01-01', '".date( "Y-m-d H:i:s", time() )."' )";
						$query = $this->db->query( $sql );
                                        }
          				$data = array(
          					'tr_number' => $tr,
          					'comment' => $comment,
          					'analysis_started' => $analysis_started,
          					'testcase_ready_for_review' => $testcase_ready_for_review,
          					'testcase_review_done' => $testcase_review_done,
          					'implemented' => $implemented,
    					        'username' => $username
          					);
          				$this->db->insert('sdp_tr_followup', $data);
  		                 } else {
                                        $pagedata['errormessage'] = 'The number must follow the following rule [a-z][a-z][0-9][0-9][0-9][0-9][0-9]';
          				$pagedata['id'] = 0;
          				$pagedata['tr_number'] = $tr;
          				$pagedata['comment'] = $comment;

                                        $pagedata['analysis_started'] = $analysis_started;
                                        $pagedata['analysis_started_time'] = sdpfollowup::prepareDateForJavascriptCalendar( $analysis_started );

                                        $pagedata['testcase_ready_for_review'] = $testcase_ready_for_review;
                                        $pagedata['testcase_ready_for_review_time'] = sdpfollowup::prepareDateForJavascriptCalendar( $testcase_ready_for_review );

                                        $pagedata['testcase_review_done'] = $testcase_review_done;
                                        $pagedata['testcase_review_done_time'] = sdpfollowup::prepareDateForJavascriptCalendar( $testcase_review_done );

                                        $pagedata['implemented'] = $implemented;
                                        $pagedata['implemented_time'] = sdpfollowup::prepareDateForJavascriptCalendar( $implemented );

                                        $this->load->view('followup/sdp_header',$pagedata);
                                        $this->load->view('followup/sdp_add_tr_followup',$pagedata);
                                        $this->load->view('followup/sdp_footer');
                                        return;
                                 }
			} else {
				// id != 0 means that we are modifying an existing release

				if( $this->input->post('Delete') == "Delete" ) {
					$data = array(
    					'deleted' => 1
    					);
					$this->db->where('id', $id );
					$this->db->update('sdp_tr_followup', $data);
					
					$message="Deleted!";
					$data = array(
						'followup_id' => $id,
						'submitted_by' => $this->session->userdata('username'),
						'submitted' => date( "Y-m-d H:i:s", time() ),
						'message' => $message
					);
					$this->db->insert('sdp_tr_followup_history', $data);
					header("Location: "."/sdpfollowup" );
					return;
				}


				// what was the old values
				$query = $this->db->query('SELECT id,tr_number,analysis_started,testcase_ready_for_review,testcase_review_done,implemented,comment,username FROM sdp_tr_followup WHERE id = '.$id);
				$release = $query->result_array();
				// print_r( $release );
				$old = array();
				$old['id'] = $release[0]['id'];
				$old['tr_number'] = $release[0]['tr_number'];
				$old['analysis_started'] = $release[0]['analysis_started'];
				$old['testcase_ready_for_review'] = $release[0]['testcase_ready_for_review'];
				$old['testcase_review_done'] = $release[0]['testcase_review_done'];; // Not Started
				$old['implemented'] = $release[0]['implemented'];
				$old['comment'] = $release[0]['comment'];
				$old['username'] = $release[0]['username'];

    				$data = array(
    					'tr_number' => $tr,
    					'comment' => $comment,
    					'analysis_started' => $analysis_started,
    					'testcase_ready_for_review' => $testcase_ready_for_review,
    					'testcase_review_done' => $testcase_review_done,
    					'implemented' => $implemented,
         			        'username' => $username
    					);

				$this->db->where('id', $id );
				$this->db->update('sdp_tr_followup', $data);

				$message="Modified followup information, changed the following; ";

                                if( strcmp( $old['tr_number'], $tr ) != 0 ) {
					$message=$message."<br>TR# from ".$old['tr_number']." to ".$tr."\n";
				}
				if( strcmp( $old['comment'], $comment ) != 0 ) {
					$message=$message."<br>Comment from \"".$old['comment']."\"<br>to<br>\"".$comment."\"\n";
				}
				if( strcmp( $old['analysis_started'], $analysis_started ) != 0 ) {
					$message=$message."<br><strong>Analysis Started</strong> from ".$old['analysis_started']." to ".$analysis_started."\n";
				}
				if( strcmp( $old['testcase_ready_for_review'], $testcase_ready_for_review ) != 0 ) {
					$message=$message."<br><strong>TestCase Ready for Review</strong> from ".$old['testcase_ready_for_review']." to ".$testcase_ready_for_review."\n";
				}
				if( strcmp( $old['testcase_review_done'], $testcase_review_done ) != 0 ) {
					$message=$message."<br><strong>TestCase Review Done</strong> from ".$old['testcase_review_done']." to ".$testcase_review_done."\n";
				}
				if( strcmp( $old['implemented'], $implemented ) != 0 ) {
					$message=$message."<br><strong>Implemented</strong> date from ".$old['implemented']." to ".$implemented."\n";
				}
                                if( strcmp( $old['username'], $username ) != 0 ) {
					$message=$message."<br><strong>Username(Developer)</strong> from ".$old['username']." to ".$username."\n";
				}

				$data = array(
					'followup_id' => $this->input->post('id'),
					'submitted_by' => $this->session->userdata('username'),
					'submitted' => date( "Y-m-d H:i:s", time() ),
					'message' => $message
				);
				$this->db->insert('sdp_tr_followup_history', $data);

			}
			header("Location: "."/sdpfollowup" );

        }
	}
	

	function prepareDateForJavascriptCalendar( $anydate ) {
              $result = '';
              if( $anydate == null || strcmp( "0000-00-00", $anydate ) == 0 ) {
                $result = time();
              } else {
                $date_array = preg_split( "/[-\s]/", $anydate );
		$result = mktime(0,0,0,$date_array[1],$date_array[2],$date_array[0]);
              }
              return $result;
        }



}
?>
